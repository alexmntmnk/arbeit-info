package com.alex.kafka.kafkaspringmulti.service;

public interface KafkaMessageService {

    void startProcessMultiMessages();
    
}
