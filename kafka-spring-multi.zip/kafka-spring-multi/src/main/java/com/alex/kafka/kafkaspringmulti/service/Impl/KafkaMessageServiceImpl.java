package com.alex.kafka.kafkaspringmulti.service.Impl;

import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

import com.alex.kafka.kafkaspringmulti.service.KafkaMessageService;
import com.alex.kafka.kafkaspringmulti.service.KafkaProducerMultiService;

import lombok.AllArgsConstructor;

/**
 * Сервис отправки-получения сообщений
 */
@Service
@AllArgsConstructor
public class KafkaMessageServiceImpl implements KafkaMessageService {

    private final KafkaProducerMultiService kafkaProducerMultiService;

    public void startProcessMultiMessages() {
        // Пример отправки нескольких сообщений                
        kafkaProducerMultiService.sendMessages();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
}
