package com.alex.kafka.kafkaspringmulti.service;

public interface KafkaProducerMultiService {
    
    void sendMessages();
}
