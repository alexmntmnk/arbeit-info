package com.alex.kafka.kafkaspringmulti.listener;

import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.alex.kafka.kafkaspringmulti.data.Farewell;
import com.alex.kafka.kafkaspringmulti.data.Greeting;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@KafkaListener(id = "multiGroup", topics = "multitype")
public class MultiTypeKafkaListener {

    // Пометив этой аннотацией метод мы будем читать из темы нужный объект Greeting
    @KafkaHandler
    public void handleGreeting(Greeting greeting) {
        log.info("Greeting received: " + greeting);
    }

    // Пометив этой аннотацией метод мы будем читать из темы нужный объект Farewell
    @KafkaHandler
    public void handleF(Farewell farewell) {
        log.info("Farewell received: " + farewell);
    }

    // Пометив этой аннотацией метод мы будем читать из темы просто объект
    @KafkaHandler(isDefault = true)
    public void unknown(Object object) {
        log.info("Unkown type received: " + object);
    }

}
