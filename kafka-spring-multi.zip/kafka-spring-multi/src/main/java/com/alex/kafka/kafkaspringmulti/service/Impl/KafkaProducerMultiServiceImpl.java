package com.alex.kafka.kafkaspringmulti.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.alex.kafka.kafkaspringmulti.data.Farewell;
import com.alex.kafka.kafkaspringmulti.data.Greeting;
import com.alex.kafka.kafkaspringmulti.service.KafkaProducerMultiService;

@Service
public class KafkaProducerMultiServiceImpl implements KafkaProducerMultiService {
    
    @Autowired
    private KafkaTemplate<String, Object> multiTypeKafkaTemplate;

    @Value(value = "${multi.type.topic.name}")
    private String multiTypeTopicName;

    public void sendMessages() {
        multiTypeKafkaTemplate.send(multiTypeTopicName, new Greeting("Greetings-Multi", "World!"));
        multiTypeKafkaTemplate.send(multiTypeTopicName, new Farewell("Farewell--Multi", 25));
        multiTypeKafkaTemplate.send(multiTypeTopicName, "Simple string message for Multi");
    }

}
