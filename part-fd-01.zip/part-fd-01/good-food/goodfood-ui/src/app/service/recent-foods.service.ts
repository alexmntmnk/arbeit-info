import { Injectable } from '@angular/core';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class RecentFoodsService {

  constructor(private apiService: ApiService) { }

  getRecentTacos() {
    return this.apiService.get('/foods?recent');
  }

}
