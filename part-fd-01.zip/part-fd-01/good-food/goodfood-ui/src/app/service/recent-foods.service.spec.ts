import { TestBed } from '@angular/core/testing';

import { RecentFoodsService } from './recent-foods.service';

describe('RecentFoodsService', () => {
  let service: RecentFoodsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RecentFoodsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
