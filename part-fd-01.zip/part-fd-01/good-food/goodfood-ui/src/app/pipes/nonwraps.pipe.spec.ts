import { NonwrapsPipe } from './nonwraps.pipe';

describe('NonwrapsPipe', () => {
  it('create an instance', () => {
    const pipe = new NonwrapsPipe();
    expect(pipe).toBeTruthy();
  });
});
