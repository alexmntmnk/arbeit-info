import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-footer',
  templateUrl: './food-footer.component.html',
  styleUrls: ['./food-footer.component.scss']
})
export class FoodFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
