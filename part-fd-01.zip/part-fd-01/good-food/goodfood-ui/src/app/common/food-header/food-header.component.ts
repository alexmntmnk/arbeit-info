import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/service/cart.service';

@Component({
  selector: 'app-food-header',
  templateUrl: './food-header.component.html',
  styleUrls: ['./food-header.component.scss']
})
export class FoodHeaderComponent implements OnInit {

  cart: CartService;

  constructor(cart: CartService) {
    this.cart = cart;
  }

  ngOnInit(): void {
  }

}
