import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FoodCartComponent } from './module/food-cart/food-cart.component';
import { FoodDesignComponent } from './module/food-design/food-design.component';
import { FoodSpecialsComponent } from './module/food-specials/food-specials.component';
import { HomeComponent } from './module/home/home.component';
import { LocationsCloudComponent } from './module/locations-cloud/locations-cloud.component';
import { LoginCloudComponent } from './module/login-cloud/login-cloud.component';
import { RecentFoodsComponent } from './module/recent-foods/recent-foods.component';

export const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'login',
    component: LoginCloudComponent
  },
  {
    path: 'recents',
    component: RecentFoodsComponent
  },
  {
    path: 'specials',
    component: FoodSpecialsComponent
  },
  {
    path: 'locations',
    component: LocationsCloudComponent
  },
  {
    path: 'design',
    component: FoodDesignComponent
  },
  {
    path: 'cart',
    component: FoodCartComponent
  },
  {
    path: '**',
    redirectTo: 'home',
    pathMatch: 'full'
  },
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
