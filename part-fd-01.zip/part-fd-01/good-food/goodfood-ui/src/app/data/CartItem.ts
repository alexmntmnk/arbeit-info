export class CartItem {

    quantity = 1;
  
    food: any;
  
    constructor(food: any) {
      this.food = food;
    }
  
    get lineTotal() {
      return this.quantity * 4.99;
    }
  
}
  