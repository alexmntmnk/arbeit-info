import { Type } from "./enums/StatusType";

export class Ingredient {
  
    id: string;
    name: string;
    type: Type;
  
    constructor(id: string, name: string, type: Type) {
      this.id = id;
      this.name = name;
      this.type = type;
    }
  
    // get lineTotal() {
    //   return this.quantity * 4.99;
    // }
  
}
  