import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FoodFooterComponent } from './common/food-footer/food-footer.component';
import { FoodHeaderComponent } from './common/food-header/food-header.component';
import { FoodCartComponent } from './module/food-cart/food-cart.component';
import { HomeComponent } from './module/home/home.component';
import { CloudTitleComponent } from './common/cloud-title/cloud-title.component';
import { LoginCloudComponent } from './module/login-cloud/login-cloud.component';
import { GroupBoxComponent } from './module/group-box/group-box.component';
import { BigButtonComponent } from './module/big-button/big-button.component';
import { LittleButtonComponent } from './module/little-button/little-button.component';
import { FoodSpecialsComponent } from './module/food-specials/food-specials.component';
import { FoodDesignComponent } from './module/food-design/food-design.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { WrapsPipe } from './pipes/wraps.pipe';
import { NonwrapsPipe } from './pipes/nonwraps.pipe';
import { LocationsCloudComponent } from './module/locations-cloud/locations-cloud.component';
import { RecentFoodsComponent } from './module/recent-foods/recent-foods.component';

@NgModule({
  declarations: [
    AppComponent,
    FoodFooterComponent,
    FoodHeaderComponent,
    FoodCartComponent,
    HomeComponent,
    CloudTitleComponent,
    LoginCloudComponent,
    GroupBoxComponent,
    BigButtonComponent,
    LittleButtonComponent,
    FoodSpecialsComponent,
    FoodDesignComponent,
    WrapsPipe,
    NonwrapsPipe,
    LocationsCloudComponent,
    RecentFoodsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
