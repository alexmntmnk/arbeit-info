import { HttpClient } from '@angular/common/http';
import { Component, Injectable, OnInit } from '@angular/core';

@Component({
  selector: 'app-recent-foods',
  templateUrl: './recent-foods.component.html',
  styleUrls: ['./recent-foods.component.scss']
})
@Injectable()
export class RecentFoodsComponent implements OnInit {

  recentFoods: any;

  constructor(private httpClient: HttpClient) { }

  ngOnInit() {
    this.httpClient.get('http://localhost:8080/api/foods?recent') // <1>
        .subscribe(data => this.recentFoods = data);
  }

}
