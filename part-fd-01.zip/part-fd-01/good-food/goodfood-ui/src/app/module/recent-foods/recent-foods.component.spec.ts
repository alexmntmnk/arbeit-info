import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecentFoodsComponent } from './recent-foods.component';

describe('RecentFoodsComponent', () => {
  let component: RecentFoodsComponent;
  let fixture: ComponentFixture<RecentFoodsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecentFoodsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RecentFoodsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
