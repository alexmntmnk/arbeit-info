import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-cloud',
  templateUrl: './login-cloud.component.html',
  styleUrls: ['./login-cloud.component.scss']
})
export class LoginCloudComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
