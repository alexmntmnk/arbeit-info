import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginCloudComponent } from './login-cloud.component';

describe('LoginCloudComponent', () => {
  let component: LoginCloudComponent;
  let fixture: ComponentFixture<LoginCloudComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginCloudComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginCloudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
