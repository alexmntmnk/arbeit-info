import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-box',
  templateUrl: './group-box.component.html',
  styleUrls: ['./group-box.component.scss']
})
export class GroupBoxComponent implements OnInit {
  @Input() title!: String;

  constructor() { }

  ngOnInit(): void {
  }

}
