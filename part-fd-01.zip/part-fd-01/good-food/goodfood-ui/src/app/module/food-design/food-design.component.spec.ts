import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodDesignComponent } from './food-design.component';

describe('FoodDesignComponent', () => {
  let component: FoodDesignComponent;
  let fixture: ComponentFixture<FoodDesignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FoodDesignComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodDesignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
