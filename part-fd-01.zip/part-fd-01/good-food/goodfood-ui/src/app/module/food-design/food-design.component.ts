import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ingredient } from 'src/app/data/Ingredient';
import { CartService } from 'src/app/service/cart.service';

@Component({
  selector: 'app-food-design',
  templateUrl: './food-design.component.html',
  styleUrls: ['./food-design.component.scss']
})
@Injectable()
export class FoodDesignComponent implements OnInit {

  model = {
    name: '',
    ingredients: [] as any[]
  };

  allIngredients: any;
  wraps = [] as Ingredient[];
  proteins = [] as Ingredient[];
  veggies = [] as Ingredient[];
  cheeses = [] as Ingredient[];
  sauces = [] as Ingredient[];

  constructor(private httpClient: HttpClient, private router: Router, private cart: CartService) {
  }

  // tag::ngOnInit[]
  ngOnInit() {
    this.httpClient.get('http://localhost:8080/api/ingredients')
        .subscribe(data => {
          this.allIngredients = data;
          this.wraps = this.allIngredients.filter((w: { type: string; }) => w.type === 'WRAP');
          this.proteins = this.allIngredients.filter((p: { type: string; }) => p.type === 'PROTEIN');
          this.veggies = this.allIngredients.filter((v: { type: string; }) => v.type === 'VEGGIES');
          this.cheeses = this.allIngredients.filter((c: { type: string; }) => c.type === 'CHEESE');
          this.sauces = this.allIngredients.filter((s: { type: string; }) => s.type === 'SAUCE');
        });
  }
  // end::ngOnInit[]

  updateIngredients(ingredient: any, event: any) {
    if (event.target.checked) {
      this.model.ingredients.push(ingredient);
    } else {
      this.model.ingredients.splice(this.model.ingredients.findIndex(i => i === ingredient), 1);
    }
  }

  // tag::onSubmit[]
  onSubmit() {
    this.httpClient.post(
        'http://localhost:8080/api/foods',
        this.model, {
            headers: new HttpHeaders().set('Content-type', 'application/json'),
        }).subscribe(taco => this.cart.addToCart(taco));

    this.router.navigate(['/cart']);
  }
  // end::onSubmit[]

}
