import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationsCloudComponent } from './locations-cloud.component';

describe('LocationsCloudComponent', () => {
  let component: LocationsCloudComponent;
  let fixture: ComponentFixture<LocationsCloudComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LocationsCloudComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationsCloudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
