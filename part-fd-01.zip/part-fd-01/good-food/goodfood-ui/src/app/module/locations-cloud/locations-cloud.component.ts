import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-locations-cloud',
  templateUrl: './locations-cloud.component.html',
  styleUrls: ['./locations-cloud.component.scss']
})
export class LocationsCloudComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
