import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodSpecialsComponent } from './food-specials.component';

describe('FoodSpecialsComponent', () => {
  let component: FoodSpecialsComponent;
  let fixture: ComponentFixture<FoodSpecialsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FoodSpecialsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodSpecialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
