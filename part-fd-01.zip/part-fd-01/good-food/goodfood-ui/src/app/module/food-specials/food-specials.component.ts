import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-specials',
  templateUrl: './food-specials.component.html',
  styleUrls: ['./food-specials.component.scss']
})
export class FoodSpecialsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
