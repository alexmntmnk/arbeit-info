package com.sha.springbootbookseller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBookSellerApplicationTests {

	@Test
	void contextLoads() {
	}

}
