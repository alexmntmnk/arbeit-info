package com.sha.springbootbookseller.model;

/**
 * @author sa
 * @date 3.07.2021
 * @time 16:56
 */
public enum Role
{
    USER, //default
    ADMIN, // admin manager, CRUD
    SYSTEM_MANAGER // internal operations.
}
