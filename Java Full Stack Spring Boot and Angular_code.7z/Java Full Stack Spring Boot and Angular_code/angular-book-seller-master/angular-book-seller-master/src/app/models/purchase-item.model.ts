export class PurchaseItem {
  title: string = "";
  price: number = 0;
  purchaseTime: Date = new Date();
}
