package com.alex.kafka.kafkaspringnext.service;

public interface KafkaMessageService {

    void startProcessMessages();
    
}
