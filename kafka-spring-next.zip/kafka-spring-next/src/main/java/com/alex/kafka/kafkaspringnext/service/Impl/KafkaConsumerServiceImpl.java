package com.alex.kafka.kafkaspringnext.service.Impl;

import java.util.concurrent.CountDownLatch;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.alex.kafka.kafkaspringnext.data.Greeting;
import com.alex.kafka.kafkaspringnext.service.KafkaConsumerService;

import lombok.extern.slf4j.Slf4j;

/**
 * В этом сервис представлены различне варианты чтения сообщений
 */
@Slf4j
@Service
public class KafkaConsumerServiceImpl implements KafkaConsumerService {

    private static final Integer CONSUMER_COUNT = 3;
    private static final Integer CONSUMER_COUNT_PARTITION = 2;
    private static final Integer CONSUMER_COUNT_FILTER = 2;
    private static final Integer CONSUMER_COUNT_GREETING = 1;
    
    // Создаем CountDownLatch на messagesPerRequest "условий", и пока они не будут все выполнены программа дальше не пойдет
    private CountDownLatch latch = new CountDownLatch(CONSUMER_COUNT);

    private CountDownLatch partitionLatch = new CountDownLatch(CONSUMER_COUNT_PARTITION);

    private CountDownLatch filterLatch = new CountDownLatch(CONSUMER_COUNT_FILTER);

    private CountDownLatch greetingLatch = new CountDownLatch(CONSUMER_COUNT_GREETING);    

    // Это сообщение должено быть получен обоими слушателями с группой foo
    // и bar с containerFactory fooKafkaListenerContainerFactory
    // и barKafkaListenerContainerFactory соответственно.
    // Оно будет также получено слушателем с
    // headersKafkaListenerContainerFactory как контейнерная фабрика.
    
    @KafkaListener(topics = "${message.topic.name}", groupId = "foo", containerFactory = "fooKafkaListenerContainerFactory")
    public void listenGroupFoo(String message) {
        log.info("Received Message in group 'foo': " + message);
        // Уменьшаем счетчик на 1
        latch.countDown();
    }

    @KafkaListener(topics = "${message.topic.name}", groupId = "bar", containerFactory = "barKafkaListenerContainerFactory")
    public void listenGroupBar(String message) {
        log.info("Received Message in group 'bar': " + message);
        latch.countDown();
    }

    @KafkaListener(topics = "${message.topic.name}", containerFactory = "headersKafkaListenerContainerFactory")
    public void listenWithHeaders(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition) {
        log.info("Received Message: " + message + " from partition: " + partition);
        latch.countDown();
    }

    /**
     * Настраиваем слушателя на чтение из 0 и 3 раздела
     * @param message полцченное сообщение
     * @param partition разделы
     */
    @KafkaListener(topicPartitions = @TopicPartition(topic = "${partitioned.topic.name}", partitions = { "0", "3" }), 
            containerFactory = "partitionsKafkaListenerContainerFactory")
    public void listenToPartition(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition) {
        log.info("Received Message: " + message + " from partition: " + partition);
        this.partitionLatch.countDown();
    }

    @KafkaListener(topics = "${filtered.topic.name}", containerFactory = "filterKafkaListenerContainerFactory")
    public void listenWithFilter(String message) {
        log.info("Received Message in filtered listener: " + message);
        this.filterLatch.countDown();
    }

    @KafkaListener(topics = "${greeting.topic.name}", containerFactory = "greetingKafkaListenerContainerFactory")
    public void greetingListener(Greeting greeting) {
        log.info("Received greeting message: " + greeting);       
        this.greetingLatch.countDown();
    }    

    public CountDownLatch getLatch () {
        return latch;
    }

    public CountDownLatch getPartitionLatch () {
        return partitionLatch;
    }

    public CountDownLatch getFilterLatch () {
        return filterLatch;
    }

    public CountDownLatch getGreetingLatch () {
        return greetingLatch;
    }    

}
