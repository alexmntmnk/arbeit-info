package com.alex.kafka.kafkaspringnext.service;

import java.util.concurrent.CountDownLatch;

public interface KafkaConsumerService {

    CountDownLatch getLatch ();

    CountDownLatch getPartitionLatch ();

    CountDownLatch getFilterLatch ();

    CountDownLatch getGreetingLatch ();
    
}
