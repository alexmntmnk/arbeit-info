package com.alex.kafka.kafkaspringnext.service;

import com.alex.kafka.kafkaspringnext.data.Greeting;

public interface KafkaProducerService {

    void sendMessage(String msg);
    void sendMessageConfirm(String message);
    void sendMessageToPartition(String message, int partition);
    void sendMessageToFiltered(String message);
    void sendGreetingMessage(Greeting greeting);
        
}
