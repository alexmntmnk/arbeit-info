package com.alex.kafka.kafkaspringnext.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.alex.kafka.kafkaspringnext.data.Greeting;
import com.alex.kafka.kafkaspringnext.service.KafkaProducerService;

import lombok.extern.slf4j.Slf4j;

/**
 * Тут описаны различные способы отправки сообщений.
 * Отправка сообщений производится в тему 'baeldung'.
 */
@Service
@Slf4j
public class KafkaProducerServiceImpl implements KafkaProducerService {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    private KafkaTemplate<String, Greeting> greetingKafkaTemplate;    

    @Value(value = "${message.topic.name}")
    private String topicName;    

    @Value(value = "${partitioned.topic.name}")
    private String partitionedTopicName;

    @Value(value = "${filtered.topic.name}")
    private String filteredTopicName;

    @Value(value = "${greeting.topic.name}")
    private String greetingTopicName;    

    /**
     * Самый простой способ отправки сообщений
     * @param message
     */
    public void sendMessage(String message) {
        kafkaTemplate.send(topicName, message);
        log.info("Sent message");
    }
 
    /**
     * Отправка сообщения с подтверждением об отправке
     * @param message
     */
    public void sendMessageConfirm(String message) {
        ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send(topicName, message);

        future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

            @Override
            public void onSuccess(SendResult<String, String> result) {
                log.info("Confirm Sent message=[" + message + "] with offset=[" + result.getRecordMetadata()
                .offset() + "]");
            }

            @Override
            public void onFailure(Throwable ex) {
                log.info("Unable to send message=[" + message + "] due to : " + ex.getMessage());
            }
        });
    }    
        
    /**
     * Посылаем собощение в тему в конкретный раздел, каждое сообщение будет отправлено в указынный раздел. 
     * 
     * @param message
     * @param partition
     */
    public void sendMessageToPartition(String message, int partition) {
        kafkaTemplate.send(partitionedTopicName, partition, null, message);
    }

    /**
     * Отправка сообщений в тему с фильтрами
     * @param message
     */
    public void sendMessageToFiltered(String message) {
        kafkaTemplate.send(filteredTopicName, message);
    }
    
    // Отправка пользовательских объектов в сообщении
    public void sendGreetingMessage(Greeting greeting) {
        greetingKafkaTemplate.send(greetingTopicName, greeting);
    }    

}
