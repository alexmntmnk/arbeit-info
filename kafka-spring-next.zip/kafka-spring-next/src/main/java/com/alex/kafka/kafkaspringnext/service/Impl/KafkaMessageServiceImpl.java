package com.alex.kafka.kafkaspringnext.service.Impl;

import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

import com.alex.kafka.kafkaspringnext.data.Greeting;
import com.alex.kafka.kafkaspringnext.service.KafkaConsumerService;
import com.alex.kafka.kafkaspringnext.service.KafkaMessageService;
import com.alex.kafka.kafkaspringnext.service.KafkaProducerService;

import lombok.AllArgsConstructor;

/**
 * Сервис отправки-получения сообщений
 */
@Service
@AllArgsConstructor
public class KafkaMessageServiceImpl implements KafkaMessageService {

    private final KafkaProducerService kafkaProducerService;
    private final KafkaConsumerService kafkaConsumerService;

    public void startProcessMessages() {

        kafkaProducerService.sendMessage("Hello, World!");
        kafkaProducerService.sendMessage("Hello, World! Two");
        kafkaProducerService.sendMessage("Hello, World! Three");
        kafkaProducerService.sendMessageConfirm("Hello, World! Confirm");

        try {
            kafkaConsumerService.getLatch().await(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Отправка сообщения в тему с пятью разделами
        // Но согласно конфигурации слушателя, только будут потребляться сообщения от разделов 0 и 3.
        for (int i = 0; i < 5; i++) {
            kafkaProducerService.sendMessageToPartition("Hello To Partitioned Topic!", i);
        }
        try {
            kafkaConsumerService.getPartitionLatch().await(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Отправка сообщений в тему с фильтрами, которая настроена так что будут проигнорированы все сообщения содержащие 'World'
        kafkaProducerService.sendMessageToFiltered("Hello Baeldung!");
        kafkaProducerService.sendMessageToFiltered("Hello World!");
        try {
            kafkaConsumerService.getFilterLatch().await(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Отправляем в качестве сообщения объект Greeting
        kafkaProducerService.sendGreetingMessage(new Greeting("Greetings", "World!"));
        try {
            kafkaConsumerService.getGreetingLatch().await(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }        

    }
    
}
