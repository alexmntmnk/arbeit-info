package com.alex.kafka.kafkaspringnext;


import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.KafkaTemplate;

import com.alex.kafka.kafkaspringnext.data.Farewell;
import com.alex.kafka.kafkaspringnext.data.Greeting;
import com.alex.kafka.kafkaspringnext.service.KafkaMessageService;

@SpringBootApplication
public class KafkaSpringNextApplication implements CommandLineRunner {


    /*
Рабочая версия - разбить на две части и перед этим добавить еще и простой мульти обмен из статьи
добавить в этот проект с отправкой 500 сообщений
добавить проект из хабра с мониторингом
добавить проект отправка с подтверждением о прочтении
посомтреть тут возможно оно
https://www.baeldung.com/spring-retry-kafka-consumer 

Добавить тестирование в проекты

 */

    @Resource
    KafkaMessageService kafkaMessageService;
  
	public static void main(String[] args) {
		SpringApplication.run(KafkaSpringNextApplication.class, args);
		// ConfigurableApplicationContext context = SpringApplication.run(KafkaSpringNextApplication.class, args);

        // MessageProducerLocal producer = context.getBean(MessageProducerLocal.class);
        // MessageProducer producer = context.getBean(MessageProducer.class);
        // MessageListener listener = context.getBean(MessageListener.class);		      
    		 
        // producer.sendMessage("Hello, World!");
        // try {
		// 	listener.latch.await(10, TimeUnit.SECONDS);
		// } catch (InterruptedException e) {
		// 	e.printStackTrace();
		// }

        // producer.sendMessages();

        // try {
        //     Thread.sleep(5000);
        // } catch (InterruptedException e) {
        //     e.printStackTrace();
        // }
        // context.close();

	}

    @Override
    public void run(String... arg) throws Exception {
        kafkaMessageService.startProcessMessages();
    }


	// public static class MessageProducer {

    //     @Autowired
    //     private KafkaTemplate<String, String> kafkaTemplate;


    //     @Value(value = "${message.topic.name}")
    //     private String topicName;

	// 	public void sendMessage(String msg) {
	// 		kafkaTemplate.send(topicName, msg);
	// 	}

    // }
	
    // @Bean
    // public MessageProducer messageProducer() {
    //     return new MessageProducer();
    // }

    // @Bean
    // public MessageListener messageListener() {
    //     return new MessageListener();
    // }

    // public static class MessageListener {

        // private CountDownLatch latch = new CountDownLatch(3);

        // @KafkaListener(topics = "${message.topic.name}", groupId = "foo", containerFactory = "fooKafkaListenerContainerFactory")
        // public void listenGroupFoo(String message) {
        //     System.out.println("Received Message in group 'foo': " + message);
        //     latch.countDown();
        // }

        // @KafkaListener(topics = "${message.topic.name}", groupId = "bar", containerFactory = "barKafkaListenerContainerFactory")
        // public void listenGroupBar(String message) {
        //     System.out.println("Received Message in group 'bar': " + message);
        //     latch.countDown();
        // }

        // @KafkaListener(topics = "${message.topic.name}", containerFactory = "headersKafkaListenerContainerFactory")
        // public void listenWithHeaders(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition) {
        //     System.out.println("Received Message: " + message + " from partition: " + partition);
        //     latch.countDown();
        // }

    // }

    // @Bean
    // public MessageProducerLocal messageProducerLocal() {
    //     return new MessageProducerLocal();
    // }


    // public static class MessageProducerLocal {

    //     @Autowired
    //     private KafkaTemplate<String, Object> multiTypeKafkaTemplate;

    //     @Value(value = "${multi.type.topic.name}")
    //     private String multiTypeTopicName;

    //     public void sendMessages() {
    //         multiTypeKafkaTemplate.send(multiTypeTopicName, new Greeting("Greetings", "World!"));
    //         multiTypeKafkaTemplate.send(multiTypeTopicName, new Farewell("Farewell", 25));
    //         multiTypeKafkaTemplate.send(multiTypeTopicName, "Simple string message");
    //     }

    // }


}
