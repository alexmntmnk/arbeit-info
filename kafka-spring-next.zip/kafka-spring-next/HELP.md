# Spring Boot Kafka Example - The Practical Developer

Еще одно простое приложение демонстрирующее работу с кафка средствами Spring.

Написано на основе документации по Spring
https://www.baeldung.com/spring-kafka

Тут работа с kafka организована через фабрики.
И представлено несколько вариантов:
- Самый простой способ отправки сообщений
- Отправка сообщений с потдверждением об отправке, но при этом мы не блокируем поток
- Отправка сообщения в тему с пятью разделами, при этом каждое сообщение отправляем в свой раздел, а чтение сообщений организовано только из от разделов 0 и 3.
- Отправка сообщений в тему с фильтрами, которая настроена так что будут проигнорированы все сообщения содержащие 'World'
- Отправка сообщений пользовательского типа в данном примере используем объект типа Greeting


Запускаем kafka server на другом хосте
docker-compose up -d
Запуск приложения
mvn spring-boot:run


Apache Kafka — это распределенная и отказоустойчивая система обработки потоков.

## Создание тем
> Раньше мы запускали инструменты командной строки для создания тем в Kafka Но с введением AdminClient в Kafka мы теперь можем создавать темы программно.

Нам нужно добавить bean- компонент KafkaAdmin Spring, который будет автоматически добавлять темы для всех bean-компонентов типа NewTopic, см. class KafkaTopicConfig

## Создание сообщений
Чтобы создавать сообщения, нам сначала нужно настроить ProducerFactory . Это задает стратегию создания экземпляров Kafka Producer .

Затем нам нужен KafkaTemplate , который обертывает экземпляр Producer и предоставляет удобные методы для отправки сообщений в темы Kafka.

Экземпляры производителя являются потокобезопасными. Таким образом, использование одного экземпляра в контексте приложения даст более высокую производительность. Следовательно, экземпляры KakfaTemplate также являются потокобезопасными, и рекомендуется использовать один экземпляр.

### Конфигурация производителя
см. class KafkaProducerConfig

## Публикация сообщений

Мы можем отправлять сообщения с помощью класса KafkaTemplate :
'''
@Autowired
private KafkaTemplate<String, String> kafkaTemplate;

public void sendMessage(String msg) {
    kafkaTemplate.send(topicName, msg);
}
'''
API отправки возвращает объект ListenableFuture . Если мы хотим заблокировать отправляющий поток и получить результат об отправленном сообщении, мы можем вызвать get API объекта ListenableFuture . Поток будет ждать результата, но это замедлит производителя.

Kafka — это платформа для быстрой обработки потоков. Поэтому лучше обрабатывать результаты асинхронно, чтобы последующие сообщения не ждали результата предыдущего сообщения.

Мы можем сделать это с помощью обратного вызова:
'''
public void sendMessage(String message) {
            
    ListenableFuture<SendResult<String, String>> future = 
      kafkaTemplate.send(topicName, message);
	
    future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

        @Override
        public void onSuccess(SendResult<String, String> result) {
            System.out.println("Sent message=[" + message + 
              "] with offset=[" + result.getRecordMetadata().offset() + "]");
        }
        @Override
        public void onFailure(Throwable ex) {
            System.out.println("Unable to send message=[" 
              + message + "] due to : " + ex.getMessage());
        }
    });
}
'''

## Использование сообщений

### Конфигурация потребителя
Для использования сообщений нам нужно настроить ConsumerFactory и KafkaListenerContainerFactory . Как только эти bean-компоненты станут доступны в фабрике bean-компонентов Spring, потребители на основе POJO можно настроить с помощью аннотации @KafkaListener .

В классе конфигурации требуется аннотация @EnableKafka , чтобы включить обнаружениеаннотации @KafkaListener в bean-компонентах, управляемых Spring : см. class KafkaConsumerConfig

### Использование сообщений
'''
@KafkaListener(topics = "topicName", groupId = "foo")
public void listenGroupFoo(String message) {
    System.out.println("Received Message in group foo: " + message);
}
'''

Мы можем реализовать несколько слушателей для темы , каждый с другим идентификатором группы. Кроме того, один потребитель может прослушивать сообщения из разных тем:

@KafkaListener(topics = "topic1, topic2", groupId = "foo")

Spring также поддерживает извлечение одного или нескольких заголовков сообщений с помощью аннотации @Header в слушателе:

'''
@KafkaListener(topics = "topicName")
public void listenWithHeaders(
  @Payload String message, 
  @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition) {
      System.out.println(
        "Received Message: " + message"
        + "from partition: " + partition);
}
'''
### Использование сообщений из определенного раздела

> Обратите внимание, что мы создали тему baeldung только с одним разделом.
Однако для темы с несколькими разделами @KafkaListener может явно подписаться на конкретный раздел темы с начальным смещением:

'''
@KafkaListener(
  topicPartitions = @TopicPartition(topic = "topicName",
  partitionOffsets = {
    @PartitionOffset(partition = "0", initialOffset = "0"), 
    @PartitionOffset(partition = "3", initialOffset = "0")}),
  containerFactory = "partitionsKafkaListenerContainerFactory")
public void listenToPartition(
  @Payload String message, 
  @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition) {
      System.out.println(
        "Received Message: " + message"
        + "from partition: " + partition);
}
'''

Поскольку в этом прослушивателе для InitialOffset установлено значение 0, все ранее использованные сообщения из разделов 0 и 3 будут повторно использоваться каждый раз при инициализации этого прослушивателя.

Если нам не нужно устанавливать смещение, мы можем использовать свойство partitions аннотации @TopicPartition , чтобы установить только разделы без смещения:
'''
@KafkaListener(topicPartitions 
  = @TopicPartition(topic = "topicName", partitions = { "0", "1" }))
'''

### Добавление фильтра сообщений для слушателей

Мы можем настроить прослушиватели для использования определенного содержимого сообщений, добавив настраиваемый фильтр. Это можно сделать, установив для RecordFilterStrategy значение KafkaListenerContainerFactory :
'''
@Bean
public ConcurrentKafkaListenerContainerFactory<String, String>
  filterKafkaListenerContainerFactory() {

    ConcurrentKafkaListenerContainerFactory<String, String> factory =
      new ConcurrentKafkaListenerContainerFactory<>();
    factory.setConsumerFactory(consumerFactory());
    factory.setRecordFilterStrategy(
      record -> record.value().contains("World"));
    return factory;
}
'''

Затем мы можем настроить прослушиватель для использования этой фабрики контейнеров:
'''
@KafkaListener(
  topics = "topicName", 
  containerFactory = "filterKafkaListenerContainerFactory")
public void listenWithFilter(String message) {
    System.out.println("Received Message in filtered listener: " + message);
}
'''
В этом прослушивателе все сообщения, соответствующие фильтру, будут отброшены.

## Пользовательские конвертеры сообщений

До сих пор мы рассматривали только отправку и получение строк в виде сообщений. Однако мы также можем отправлять и получать пользовательские объекты Java. Для этого требуется настроить соответствующий сериализатор в ProducerFactory и десериализатор в ConsumerFactory .

Давайте посмотрим на простой класс bean-компонента , который мы будем отправлять в виде сообщений:
public class Greeting {

    private String msg;
    private String name;

    // standard getters, setters and constructor
}

### Создание пользовательских сообщений

В этом примере мы будем использовать JsonSerializer .

Давайте посмотрим на код для ProducerFactory и KafkaTemplate :
'''
@Bean
public ProducerFactory<String, Greeting> greetingProducerFactory() {
    // ...
    configProps.put(
      ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, 
      JsonSerializer.class);
    return new DefaultKafkaProducerFactory<>(configProps);
}

@Bean
public KafkaTemplate<String, Greeting> greetingKafkaTemplate() {
    return new KafkaTemplate<>(greetingProducerFactory());
}
'''
Мы можем использовать этот новый KafkaTemplate для отправки приветственного сообщения:

kafkaTemplate.send(topicName, new Greeting("Hello", "World"));

### Использование пользовательских сообщений

Точно так же давайте изменим ConsumerFactory и KafkaListenerContainerFactory , чтобы правильно десериализовать приветственное сообщение:
'''
@Bean
public ConsumerFactory<String, Greeting> greetingConsumerFactory() {
    // ...
    return new DefaultKafkaConsumerFactory<>(
      props,
      new StringDeserializer(), 
      new JsonDeserializer<>(Greeting.class));
}

@Bean
public ConcurrentKafkaListenerContainerFactory<String, Greeting> 
  greetingKafkaListenerContainerFactory() {

    ConcurrentKafkaListenerContainerFactory<String, Greeting> factory =
      new ConcurrentKafkaListenerContainerFactory<>();
    factory.setConsumerFactory(greetingConsumerFactory());
    return factory;
}
'''
Сериализатор и десериализатор Spring-kafka JSON использует библиотеку Jackson , которая также является дополнительной зависимостью Maven для проекта spring-kafka.

Итак, давайте добавим его в наш pom.xml :
'''
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
    <version>2.9.7</version>
</dependency>
'''
Вместо использования последней версии Jackson рекомендуется использовать версию, указанную тут или в обновленной версии статьи, добавленную в pom.xml spring-kafka.

Наконец, нам нужно написать прослушиватель для приема приветственных сообщений:
'''
@KafkaListener(
  topics = "topicName", 
  containerFactory = "greetingKafkaListenerContainerFactory")
public void greetingListener(Greeting greeting) {
    // process greeting message
}
'''

## Мультиметодные слушатели

Давайте теперь посмотрим, как мы можем настроить наше приложение для отправки различных типов объектов в одну и ту же тему, а затем их использования.

Во-первых, мы добавим новый класс Farewell :

public class Farewell {

    private String message;
    private Integer remainingMinutes;

    // standard getters, setters and constructor
}

Нам потребуются дополнительные настройки, чтобы иметь возможность отправлять объекты Greeting и Farewell в одну и ту же тему.

### Установите типы сопоставления в Producer

В производителе мы должны настроить сопоставление типов JSON :

configProps.put(JsonSerializer.TYPE_MAPPINGS, "greeting:com.baeldung.spring.kafka.Greeting, farewell:com.baeldung.spring.kafka.Farewell");

Таким образом, библиотека заполнит заголовок типа соответствующим именем класса.

В результате ProducerFactory и KafkaTemplate выглядят так:
'''
@Bean
public ProducerFactory<String, Object> multiTypeProducerFactory() {
    Map<String, Object> configProps = new HashMap<>();
    configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
    configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
    configProps.put(JsonSerializer.TYPE_MAPPINGS, 
      "greeting:com.baeldung.spring.kafka.Greeting, farewell:com.baeldung.spring.kafka.Farewell");
    return new DefaultKafkaProducerFactory<>(configProps);
}

@Bean
public KafkaTemplate<String, Object> multiTypeKafkaTemplate() {
    return new KafkaTemplate<>(multiTypeProducerFactory());
}
'''
Мы можем использовать этот KafkaTemplate для отправки по теме приветствия , Farewell или любого другого объекта :

multiTypeKafkaTemplate.send(multiTypeTopicName, new Greeting("Greetings", "World!"));
multiTypeKafkaTemplate.send(multiTypeTopicName, new Farewell("Farewell", 25));
multiTypeKafkaTemplate.send(multiTypeTopicName, "Simple string message");

### Используйте пользовательский конвертер сообщений в потребителе

Чтобы иметь возможность десериализовать входящее сообщение, нам нужно предоставить нашему потребителю пользовательский MessageConverter .

За кулисами MessageConverter полагается на Jackson2JavaTypeMapper . По умолчанию маппер выводит тип полученных объектов: наоборот, нам нужно указать ему явно использовать заголовок типа для определения целевого класса для десериализации:

typeMapper.setTypePrecedence(Jackson2JavaTypeMapper.TypePrecedence.TYPE_ID);

Нам также необходимо предоставить информацию об обратном отображении. Нахождение «приветствия» в заголовке типа идентифицирует объект « Приветствие » , тогда как «прощание» соответствует объекту « Farewell » :
'''
Map<String, Class<?>> mappings = new HashMap<>(); 
mappings.put("greeting", Greeting.class);
mappings.put("farewell", Farewell.class);
typeMapper.setIdClassMapping(mappings);
'''
Наконец, нам нужно настроить пакеты, которым доверяет картограф. Мы должны убедиться, что он содержит расположение целевых классов:

typeMapper.addTrustedPackages("com.baeldung.spring.kafka");

В результате вот окончательное определение этого MessageConverter:
'''
@Bean
public RecordMessageConverter multiTypeConverter() {
    StringJsonMessageConverter converter = new StringJsonMessageConverter();
    DefaultJackson2JavaTypeMapper typeMapper = new DefaultJackson2JavaTypeMapper();
    typeMapper.setTypePrecedence(Jackson2JavaTypeMapper.TypePrecedence.TYPE_ID);
    typeMapper.addTrustedPackages("com.baeldung.spring.kafka");
    Map<String, Class<?>> mappings = new HashMap<>();
    mappings.put("greeting", Greeting.class);
    mappings.put("farewell", Farewell.class);
    typeMapper.setIdClassMapping(mappings);
    converter.setTypeMapper(typeMapper);
    return converter;
}
'''
Теперь нам нужно указать нашей ConcurrentKafkaListenerContainerFactory использовать MessageConverter и довольно простую ConsumerFactory :
'''
@Bean
public ConsumerFactory<String, Object> multiTypeConsumerFactory() {
    HashMap<String, Object> props = new HashMap<>();
    props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
    props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
    props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
    return new DefaultKafkaConsumerFactory<>(props);
}

@Bean
public ConcurrentKafkaListenerContainerFactory<String, Object> multiTypeKafkaListenerContainerFactory() {
    ConcurrentKafkaListenerContainerFactory<String, Object> factory = new ConcurrentKafkaListenerContainerFactory<>();
    factory.setConsumerFactory(multiTypeConsumerFactory());
    factory.setMessageConverter(multiTypeConverter());
    return factory;
}
'''

Используйте @KafkaHandler в прослушивателе

И последнее, но не менее важное: в нашем KafkaListener мы создадим метод-обработчик для извлечения всех возможных объектов. Каждый обработчик должен быть аннотирован @KafkaHandler .

В заключение отметим, что мы также можем определить обработчик по умолчанию для объектов, которые нельзя привязать ни к одному из классов Greeting или Farewell :

@Component
@KafkaListener(id = "multiGroup", topics = "multitype")
public class MultiTypeKafkaListener {

    @KafkaHandler
    public void handleGreeting(Greeting greeting) {
        System.out.println("Greeting received: " + greeting);
    }

    @KafkaHandler
    public void handleF(Farewell farewell) {
        System.out.println("Farewell received: " + farewell);
    }

    @KafkaHandler(isDefault = true)
    public void unknown(Object object) {
        System.out.println("Unkown type received: " + object);
    }
}

