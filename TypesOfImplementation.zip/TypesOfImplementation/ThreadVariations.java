/**
 * Иногда бывает необходимо скрыть потоковый код внутри класса, рассмотрим как это можно реализовать
 * Примечание: запускать поток в конструкторе - не очень хорошая идея, т.к. другая задача может начать 
 * выполнение до завершения конструктора, а это значит, что состояние объекта будет еще не стабильно.
 */
public class ThreadVariations {
    public static void main(String[] args) {
        new InnerThread1("InnerThread1");
        new InnerThread2("InnerThread2");
        new InnerRunnable1("InnerRunnable1");
        new InnerRunnable2("InnerRunnable2");
        new ThreadMethod("ThreadMethod").runTask();
      }        
}

//используя для этого внутренний класс - это очень редкая реализация
class InnerThread1 {
    private int countDown = 5;
    private Inner inner;
    private class Inner extends Thread {
      Inner(String name) {
        super(name);
        start();
      }
      public void run() {
        try {
          while(true) {
            System.out.println(this);
            if(--countDown == 0) return;
            sleep(10);
          }
        } catch(InterruptedException e) {
            System.out.println("interrupted");
        }
      }
      public String toString() {
        return getName() + ": " + countDown;
      }
    }
    public InnerThread1(String name) {
      inner = new Inner(name);
    }
  }
  
  // используя для этого анонимный внутренний класс:
  // любой метод класса InnerThread2 может обратиться к ссылке t и запустить поток
  class InnerThread2 {
    private int countDown = 5;
    private Thread t;
    public InnerThread2(String name) {
      t = new Thread(name) {
        public void run() {
          try {
            while(true) {
                System.out.println(this);
              if(--countDown == 0) return;
              sleep(10);
            }
          } catch(InterruptedException e) {
            System.out.println("sleep() interrupted");
          }
        }
        public String toString() {
          return getName() + ": " + countDown;
        }
      };
      t.start();
    }
  }
  
  // используя именованной реализации Runnable:
  class InnerRunnable1 {
    private int countDown = 5;
    private Inner inner;
    private class Inner implements Runnable {
      Thread t;
      Inner(String name) {
        t = new Thread(this, name);
        t.start();
      }
      public void run() {
        try {
          while(true) {
            System.out.println(this);
            if(--countDown == 0) return;
            Thread.sleep(10);
          }
        } catch(InterruptedException e) {
            System.out.println("sleep() interrupted");
        }
      }
      public String toString() {
        return t.getName() + ": " + countDown;
      }
    }
    public InnerRunnable1(String name) {
      inner = new Inner(name);
    }
  }
  
  // используя анонимную реализацию Runnable:
  class InnerRunnable2 {
    private int countDown = 5;
    private Thread t;
    public InnerRunnable2(String name) {
      t = new Thread(new Runnable() {
        public void run() {
          try {
            while(true) {
                System.out.println(this);
              if(--countDown == 0) return;
              Thread.sleep(10);
            }
          } catch(InterruptedException e) {
            System.out.println("sleep() interrupted");
          }
        }
        public String toString() {
          return Thread.currentThread().getName() +
            ": " + countDown;
        }
      }, name);
      t.start();
    }
  }
  
  // Отдельный метод для выполнения кода в виде задачи:
  // такое решение лучше чем запуск потока в конструкторе класса
  class ThreadMethod {
    private int countDown = 5;
    private Thread t;
    private String name;
    public ThreadMethod(String name) { this.name = name; }
    public void runTask() {
      if(t == null) {
        t = new Thread(name) {
          public void run() {
            try {
              while(true) {
                System.out.println(this);
                if(--countDown == 0) return;
                sleep(10);
              }
            } catch(InterruptedException e) {
                System.out.println("sleep() interrupted");
            }
          }
          public String toString() {
            return getName() + ": " + countDown;
          }
        };
        t.start();
      }
    }
  }
  