package com.alex.kafka.kafkaspringmanymessages.service;

import java.util.concurrent.CountDownLatch;

public interface KafkaConsumerService {

    // CountDownLatch getLatch ();

    // CountDownLatch getGreetingLatch ();
    
}
