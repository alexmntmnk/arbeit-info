package com.alex.kafka.kafkaspringmanymessages.service.Impl;

import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

import com.alex.kafka.kafkaspringmanymessages.data.Greeting;
import com.alex.kafka.kafkaspringmanymessages.data.TimeParamert;
import com.alex.kafka.kafkaspringmanymessages.service.KafkaConsumerService;
import com.alex.kafka.kafkaspringmanymessages.service.KafkaMessageService;
import com.alex.kafka.kafkaspringmanymessages.service.KafkaProducerService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Сервис отправки-получения сообщений
 */
@Slf4j
@Service
@AllArgsConstructor
public class KafkaMessageServiceImpl implements KafkaMessageService {

    private final KafkaProducerService kafkaProducerService;
    private final KafkaConsumerService kafkaConsumerService;

    public void startProcessMessages() {

        TimeParamert.start = System.currentTimeMillis();
        String message = "number message: ";
        

        // TimeParamert.count++;
        // kafkaProducerService.sendMessage(message + TimeParamert.count);
        
        for (int i = 0; i < TimeParamert.CONSUMER_COUNT; i++) {
            TimeParamert.count++;
            // Вариант 1 - отправка текстовых сообщений
            // kafkaProducerService.sendMessage(message + TimeParamert.count);            
            // Вариант 2 - отправка сообщений в виде пользователького объекта
            kafkaProducerService.sendGreetingMessage(new Greeting(message + TimeParamert.count, "World!"));            
        }
        log.info("message recive all");

        // try {
        //     kafkaConsumerService.getLatch().await(10, TimeUnit.SECONDS);
        // } catch (InterruptedException e) {
        //     e.printStackTrace();
        // }


        // Отправляем в качестве сообщения объект Greeting
        // kafkaProducerService.sendGreetingMessage(new Greeting("Greetings", "World!"));
        // try {
        //     kafkaConsumerService.getGreetingLatch().await(10, TimeUnit.SECONDS);
        // } catch (InterruptedException e) {
        //     e.printStackTrace();
        // }

    }
    
}
