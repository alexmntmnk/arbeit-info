package com.alex.kafka.kafkaspringmanymessages.service.Impl;

import java.util.concurrent.CountDownLatch;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.alex.kafka.kafkaspringmanymessages.data.Greeting;
import com.alex.kafka.kafkaspringmanymessages.data.TimeParamert;
import com.alex.kafka.kafkaspringmanymessages.service.KafkaConsumerService;

import lombok.extern.slf4j.Slf4j;

/**
 * В этом сервис представлены различне варианты чтения сообщений
 */
@Slf4j
@Service
public class KafkaConsumerServiceImpl implements KafkaConsumerService {

    private static final Integer CONSUMER_COUNT = 1;
    private static final Integer CONSUMER_COUNT_GREETING = 1;
    private static final Integer MESSAGE_COUNT = 1000;
    private int count = 1;
    
    // Это сообщение должено быть получен обоими слушателями с группой many_message
    @KafkaListener(topics = "${message.topic.name}", groupId = "many_message", containerFactory = "manyKafkaListenerContainerFactory")
    public void listenGroupFoo(String message) {
        // log.info("Received Message: {}", message);
        if (count >= MESSAGE_COUNT) {
            long elapsed = System.currentTimeMillis() - TimeParamert.start;
            log.info("General time of transfer of all messages = {}", elapsed);
        } else {
            count++;
        }
    }

    @KafkaListener(topics = "${greeting.topic.name}", containerFactory = "greetingKafkaListenerContainerFactory")
    public void greetingListener(Greeting greeting) {
        // log.info("Received greeting message: {}", greeting.getMsg());       
        if (count >= MESSAGE_COUNT) {
            long elapsed = System.currentTimeMillis() - TimeParamert.start;
            log.info("General time of transfer of all messages = {}", elapsed);
        } else {
            count++;
        }        
    }

    // public CountDownLatch getLatch () {
    //     return latch;
    // }

    // public CountDownLatch getGreetingLatch () {
    //     return greetingLatch;
    // }

/*
 long start = System.currentTimeMillis();
// выполнение какой-то логики
Thread.sleep(1000);
long finish = System.currentTimeMillis();
long elapsed = finish - start;
 */

}
