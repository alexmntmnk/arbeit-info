package com.alex.kafka.kafkaspringmanymessages.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.alex.kafka.kafkaspringmanymessages.data.Greeting;
import com.alex.kafka.kafkaspringmanymessages.service.KafkaProducerService;

import lombok.extern.slf4j.Slf4j;

/**
 * Тут описаны различные способы отправки сообщений.
 * Отправка сообщений производится в тему 'baeldung'.
 */
@Service
@Slf4j
public class KafkaProducerServiceImpl implements KafkaProducerService {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    private KafkaTemplate<String, Greeting> greetingKafkaTemplate;    

    @Value(value = "${message.topic.name}")
    private String topicName;    

    @Value(value = "${greeting.topic.name}")
    private String greetingTopicName;    

    /**
     * Самый простой способ отправки сообщений
     * @param message
     */
    public void sendMessage(String message) {
        kafkaTemplate.send(topicName, message);
        // log.info("Sent message");
    }
         
    // Отправка пользовательских объектов в сообщении
    public void sendGreetingMessage(Greeting greeting) {
        greetingKafkaTemplate.send(greetingTopicName, greeting);
    }    

}
