package com.alex.kafka.kafkaspringmanymessages.service;

public interface KafkaMessageService {

    void startProcessMessages();
    
}
