package com.alex.kafka.kafkaspringmanymessages.data;

public class TimeParamert {

    public static Integer count = 0;
    public static Long start;

    public static final Integer CONSUMER_COUNT = 1000;

    
}
