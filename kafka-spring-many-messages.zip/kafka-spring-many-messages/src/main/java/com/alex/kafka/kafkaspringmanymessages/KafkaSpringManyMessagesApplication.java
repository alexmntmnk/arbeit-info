package com.alex.kafka.kafkaspringmanymessages;

import javax.annotation.Resource;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.alex.kafka.kafkaspringmanymessages.service.KafkaMessageService;

@SpringBootApplication
public class KafkaSpringManyMessagesApplication implements CommandLineRunner {

	@Resource
    KafkaMessageService kafkaMessageService;
	
	public static void main(String[] args) {
		SpringApplication.run(KafkaSpringManyMessagesApplication.class, args);
	}

	@Override
    public void run(String... arg) throws Exception {
        kafkaMessageService.startProcessMessages();
    }

}
