package com.alex.kafka.kafkaspringmanymessages.service;

import com.alex.kafka.kafkaspringmanymessages.data.Greeting;

public interface KafkaProducerService {

    void sendMessage(String msg);
    void sendGreetingMessage(Greeting greeting);
        
}
