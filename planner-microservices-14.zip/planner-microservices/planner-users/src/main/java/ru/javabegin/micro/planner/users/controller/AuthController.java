package ru.javabegin.micro.planner.users.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth") // базовый URI
public class AuthController {


}
