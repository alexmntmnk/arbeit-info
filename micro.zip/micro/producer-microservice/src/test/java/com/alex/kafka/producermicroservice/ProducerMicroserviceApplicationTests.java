package com.alex.kafka.producermicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
