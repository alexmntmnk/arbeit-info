package com.alex.kafka.producermicroservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.alex.kafka.producermicroservice.model.FoodOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SchedulerSendMessage {

    @Value("${topic.schedule_name}")
    private String scheduleTopic;

    private final ObjectMapper objectMapper;
    
    // @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    public SchedulerSendMessage(KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper) {
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }

    private Integer count = 0;

    // @Scheduled(fixedRate = 1000)
    public void sendMessage() {
        count++;
        // kafkaTemplate.send("t.scheduled", "message " + count);
        FoodOrder foodOrder = new FoodOrder("message " + count, count * 2.5);
        String orderAsMessage;
        try {
            orderAsMessage = objectMapper.writeValueAsString(foodOrder);
            kafkaTemplate.send(scheduleTopic, orderAsMessage);
            log.info("sent message count {}", count);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
              
    }

}
