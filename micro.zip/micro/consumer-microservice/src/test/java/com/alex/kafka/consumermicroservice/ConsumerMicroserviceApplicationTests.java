package com.alex.kafka.consumermicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
