# Задание 3-4

Задача №4
Добавь к pipeline переменную TIMEZONE и вывести ее в лог консоли в pipeline
Директива environment позволяет указывать имена и значения переменных среды, которые будут доступны в рамках pipeline. Определение переменной в верхней части pipeline сделает доступной переменную во всех частях pipeline
```
environment {
    TEST_VAR = “test”
}
```
в самом pipeline можно использовать следующим образом:
```
stage ('test') {
    steps {
        echo "${TEST_VAR}"
    }
}
```

Решение задачи см. 

[Jenkinsfile-answer-3-4](code/Jenkinsfile-answer-3-4)

