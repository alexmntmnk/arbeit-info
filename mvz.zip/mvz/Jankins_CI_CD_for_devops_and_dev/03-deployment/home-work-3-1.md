# Задание 3-1

Дан репозиторий с java проектом, сборка происходит с помощью команды:
mvn clean install -Dmaven.test.skip. Тесты запускаются с помощью команды mvn test. Необходимо сделать pipeline, который выполняет  сборку и тестирование кода из ранее созданного репозитория.


После настройки директива tools позволяет указать, какие инструменты мы хотим автоматически установить и использовать в нашем pipeline
tools {
maven ‘3.8.6’
}
Для получение кода из репозитория, будет использовать встроенную возможность jenkins - git branch
git branch: ‘<branch name>’, credentialsId: '<id credentials>', url: '<repo url>'
Пример использования:
```
git branch: 'main', credentialsId: 's043218-dev-gitlab', url: 'https://gitlab.slurm.io/jenkins/spring-boot-rest-example.git'
```
Для запуска определенного шага в pipeline используется секция stages с множеством stage внутри
Пример:
```
stages {
    stage ('Example Stage') {
        steps {
        sh 'echo "Hello, Slurm"'
        }
    }
}

```

Решение задачи см. 

[Jenkinsfile-answer-3-1](code/Jenkinsfile-answer-3-1)

