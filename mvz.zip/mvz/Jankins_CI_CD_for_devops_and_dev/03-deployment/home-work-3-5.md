# Задание 3-5

Задача №5
Добавить шаг сборки docker image с публикацией на docker hub
Устанавливаем плагин https://plugins.jenkins.io/docker-workflow/ (см урок 2)
Важно! на slave agent должен быть установлен докер и пользователь jenkins должен входить в группу docker. Более детально по ссылке https://docs.docker.com/engine/install/linux-postinstall/
Также после добавления пользователя jenkins на slave в docker группу, необходимо сделать Disconnect агента и заново его подключить
На docker hub создать персональный токен и добавить его в credentials jenkins как username/password. Где username логин на docker hub, а пароль сгенерированный токен
Для того чтобы собрать docker, используется команда docker.build(<имя образа>), которая возвращает docker image и его можно дальше использовать в других командах
Пример
```
stage('docker build') {
    steps {
        script{
            app = docker.build("silabeer/spring-boot-rest-example")
        }
    }
}
```

Для регистрации docker registry и дальнейшей работы с ним используются директивы:
1.	docker.withRegistry(<registryUrl>, <registryCredentialsId>)
2.	docker.withServer(<serverUri>, <serverCredentialsId>)
Пример:
```
stage('docker push') {
    steps {
        script{
            docker.withRegistry('https://registry.hub.docker.com', 'dev-dockerhub') {
                app.push("${env.BUILD_NUMBER}")
            }
        }
    }
}
```

Важно: шаги docker оборачиваются в директиву script

Решение задачи см. 

[Jenkinsfile-answer-3-5](code/Jenkinsfile-answer-3-5)

