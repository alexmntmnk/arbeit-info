# Задание 3-2

Задача №2
Добавить к ранее созданному pipeline, запуск по расписанию, каждые 30 минут
Для определения расписания запуска pipeline используется секция trigger. Он принимает 4 значения: cron, upstream, githubPush, pollSCM
cron - запускает задание по заданому расписанию, а pollSCM запуска проверку обновлений исходного кода, если будет обнаружено изменение то запускает выполнение pipeline
Пример:
trigger { *cron(15 * * * )  }
запуск конвейера через четверть часа
trigger { pollSCM(/20 * * * ) }
 cканируем на наличие изменений SCM с 20-минутными интервалами
upstream - запускает задание по условию выполненного другого задания
Пример:
trigger { upstream(upstreamProjects: 'trigger-job', threshold:hudson.model.Result.SUCCESS) }
начнет выполнение после успешного выполнения джобы trigger-job
githubPush - запускает pipeline в случае получения webhook от github


Решение задачи см. 

[Jenkinsfile-answer-3-2](code/Jenkinsfile-answer-3-2)

