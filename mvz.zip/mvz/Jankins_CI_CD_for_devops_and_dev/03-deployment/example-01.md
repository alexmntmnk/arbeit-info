# Первый пример деплоя приложения

## Настроим Credentional для gitlab
В Gitlab создаем Project токен, а Jenkins
Manage Jenkins-> System
секция Gitlab
![Credentials-gitlab](images/Credentials-gitlab.png)

> Через токен у меня не получилось, он не отображается в списках Credentials проекта, поэтому сделал как и в лекции через user/password

Сам проект лежит у нас в корне spring-boot-rest-example-main, и необходимо поместить его в свой репозиторий на gilab
Т.к. это maven проект, то создадим tools maven, мы уже это делали на втором уроке

> Тут Мы не будем подключаться из gitlab к пректу Jenkins (extensions or webhook), а будем работать непосредственно с репозиторием из Pipeline

В написнаии кода нам поможет Snippet-Generator, заходим в него, это можно сделать открыв любой проект и выбрав секцию Pipeline Syntax
Далее выбираем Snippet-Generator -> Sample Step -> Git

![Snippet-Generator-git](images/Snippet-Generator-git.png)

заполняем все поля
![Snippet-Generator-git-set](images/Snippet-Generator-git-set.png)
и генерируем код

```
git branch: 'deployment-01', credentialsId: 'user-name-gitlab', url: 'http://te-nck-lin012.tmh-eng.ru/slurm/spring-boot-rest-example-main.git'
```
и добавляем ее в наш шаг stage Credentials
```
    stages {
        stage('Credentials'){
            steps{
                git branch: 'develop', credentialsId: 'user-name-gitlab', url: 'http://te-nck-lin012.tmh-eng.ru/slurm/spring-boot-rest-example-main.git'
            }
        }
    }
```
Добавим еще один stage и пока пропустим тесты
```
        stage ('build') {
            steps {
                sh 'mvn clean install -Dmaven.test.skip'
            }
        }        
```

Полностью пример приведен в файле
[Jenkinsfile-03](code/Jenkinsfile-03)

Запускаем нашу сборку