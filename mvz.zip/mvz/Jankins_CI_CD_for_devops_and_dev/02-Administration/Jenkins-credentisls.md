# Jenkins credentisls

Для создания нового credentials открываем web-интерфейс Jenkins
Manage Jenkins -> Manage Credentials

![create-credentials](image/create-credentials.png)

Тут мы видим нескоько вариантов настроек секрета
пароль/токен/текст/файл/сертификат

далеее выбираем global/system

Лучше использовать system

id - обязательно задаем это поле, особенно, когда у нас много проектов
рекомендации для задания этого поля
<projectId>-<env>-<description>
env - например dev, prod
myProject-dev-sonar
myProject-dev-gitlab

Заполняем необходимые поля:
1.	Kind: Тип секрета
2.	Scope: Область видимости
3.	Username: Имя пользователя
4.	Treat username as secret: если выставить галочку, то имя пользователя в pipeline, будет прятаться за ***
5.	Password: Пароль пользователя
6.	ID: уникальный идентификатор
7.	Description: Краткое описание

