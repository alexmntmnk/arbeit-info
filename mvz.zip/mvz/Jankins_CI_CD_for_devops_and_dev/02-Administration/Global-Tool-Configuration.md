# Global-Tool-Configuration

Это очень важная штука.
Когда мы подключаем своих агентов в своих проектах. и мы запускаем там всякие сборки Maven, Gradle, JDK, Node, Sobnar и т.д. нам необходимо их все иметь на своем агенте. Как делают обычно, берут ансибле плэйбоок и накатывают туда какую-то версию Maven, Gradle, JDK, Node, Sobnar и т.д. и если выходит какая-то новая версия этой либы, то создаем еще одного агента туда ставим новую версию либы, помечаем новыми метками.
Но есть вариант на много проще и это
### Global Tool Configuration
Эта штука позволяет в мемент запуска piprline определить секцию с тулами и предварительно настроив их Jenkins скачает их на машину и установим паку с бинами Maven, Gradle, JDK, Node, Sobnar и т.д. и мы можем использовать их не устанавливая в ручную.
>Kenkins предлагает по умолчанию имеет следующие сборки
>Maven, Gradle, JDK


Добавить maven и npm в Global Tool Configuration

Рассмотрим на примере установки maven, для этого перейдем в Manage Jenkins-> Global Tool Configuration

![manage-global-tool-conf](image/manage-global-tool-conf.png)

Заходим туда и мы сразу видим тулы идущие из коробки, которые на предлагает Jenkins
Нажимаем Add Maven
![add-maven](image/add-maven.png)

Заполняем обязательные поля
назовем его maven-3-8.6
![settings-maven](image/settings-maven.png)
Если в организации закрыт доступ в интернет, то на рисуке мы видим в выпадющем списке четыре других спооба установки без интеренета
Например extracyt zip - мы помещаю сюда свой архив, а Jenkins его потом сам разорхивирует и положит куда надо.
Чаще используют run shell com
с помощью wget загружают его и ставять куда угодно

Теперь создадим тестовый pipeline со следующим скриптом
```
pipeline {
    agent any
    stages {
        stage('Test maven'){
            steps{
                sh 'mvn -version'
            }
        }
    }
}
```
И убедимся что наш pipeline не прошел, т.к. у нас нет maven.
А теперь добавим наш maven из тулс.

Изменим наш скрипт, добавив наш tools 
```
pipeline {
    agent any
    tools{
        maven 'maven-3.9.3'
    }
    stages {
        stage('Test maven'){
            steps{
                sh 'mvn -version'
            }
        }
    }
}
```

И мы видим, что наш pipeline сработал
