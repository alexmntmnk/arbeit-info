# Администрирование

## Slave Agent

У нас есть некоторый master и мы имеем некоторое кол-во Slave-Agent, которые выполняют некоторые задания. Т.е. это сущность, которая выполняют ту работу которую ей дилегирует наш мастер.
Jenkins в качестве Slave-Agent может использовать много вариантов: виндовая маш9ина, линуксовая машина, докер агенты, кубы и т.д.
Если раньше чаще всего использовали Linux агенты, то щас чаще всего стали использовать Docker-контейнеры, которые дают большую изоляцию, еще более продвинутый уровень это кубер-агенты
Пока что познакомимся с Linux-агентами
![Slave-Agent](image/slave-agent.png)

Агенты подключаются двумя методами 
- SSH рекомендуется этот способ
- JNLP

Требования для Slave
- Наличие JRE/JDK на VM
- SSH порт (22) открыт и доступен

Best practics:
- использовать SSH
- избегать JNLP через браузер, хотя иногода оно необходимо, например при использовании Selenium тестировании
- определяйте tools (рассмотрим позднее)

При установке Jenkins мы увидим только одну node Build-In , это и есть наш мастер, раньше она так и называлась. 
> На Build-In не рекомендуется запускать ни какие bulds!!!

Вармант подключения через JNLP:
https://hub.docker.com/r/jenkins/inbound-agent
необходимо будет открыть 50000 порт

еще одни вариант от oroinc (репа лежит в архиве), см. папку [jenkins](../oroinc/docker-build-master/jenkins/)
https://github.com/oroinc/docker-build

Вармант подключения через SSH, используется sshd:

Статья [Docker _ Jenkins Master and Slave - 2021](../Jenkins%20Master%20and%20Slave/Docker%20_%20Jenkins%20Master%20and%20Slave%20-%202021.mhtml)
В статье описан пример со старой версией, а вот тут лежит последняя версия [docker-ssh-agent](https://github.com/jenkinsci/docker-ssh-agent/tree/master)

А вот пример от Slurm
[create linux agent](create-linux-agent.md)

Добавляем плагины 
[add plugins](add-plugins.md)

Очень важная тема
[Global-Tool-Configuration](Global-Tool-Configuration.md)

Секреты
[Jenkins-credentisls](Jenkins-credentisls.md)

Authentification
[Jenkins-Authentification](Jenkins-Authentification.md)