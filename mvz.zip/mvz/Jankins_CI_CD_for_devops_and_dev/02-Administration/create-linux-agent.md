# create linux agent

У нас есть две машины vs01 и vs02
master будет на vs01
linux agent будет на vs02

### Заходим на vs01 машину

Запускаем файл
[docker-compose](data/docker-compose.yml)

```docker-compose up -d```

Выполняем первоначальную настройку jenkins
Генерируем ssh ключ:
```ssh-keygen -t rsa -f jenkins_slave```

Выполняем команду и копируем содержимое файла
```cat jenkins_slave```
Открываем web-интерфейс Jenkins, переходим в Manage Jenkins-> Manage Credentials

![manage-jenkins](image/manage-jenkins.png)

Переходим в домен global

![domain-global](image/domain-global.png)

Нажимаем Add Credentials, заполняем как на скриншотах ниже, в поле для ключа вводим ранее скопированный приватный ключ

Имя пользователя задаем jenkins

![Add-Credentials 01](image/Add-Credentials-01.png)
![Add-Credentials 02](image/Add-Credentials-02.png)

Жмем Create

### Заходим на vs02 сервер

Устанавливаем java
```apt install openjdk-11-jre-headless```
Создаем пользователя jenkins и задаем для него пароль
```
sudo useradd -m -s /bin/bash jenkins
sudo passwd jenkins
```

### Возвращаемся на vs01 и копируем публичные ключи на наш slave

```ssh-copy-id -i jenkins_slave.pub  jenkins@vs02```

Переходим в web интерфейс Jenkins - Manage Jenkins -> Manage Node and Cloud

Manage Node and Cloud - в последней верисии просто Nodes

![manage-node](image/manage-node.png)

Нажимаем New Node, вводим произвольное имя агента, и ставим галочку Permanent Agent

![new-node](image/new-node.png)

Заполняем обязательные поля

![create-node](image/create-node.png)

- Name: имя агента
- Description: описание
- Number of executors: количество параллельных заданий на агенте, рекомендуется 1-2 CPU на агенте
- Remote root directory: домашняя директория для Jenkins, это дирректолрия пользователя, можно задавать любую
- Label: метка по которой Jenkins будет группировать slave agent
- Usege: тут выбираем или запускать все задания или только те которые помечены этой меткой
- Launch method: выбираем via SSH
- Host: hostname или IP адрес агента
- Credentials: выбираем ранее созданный секрет

![create-node-next](image/create-node-next.png)

Далее запоняем поля
Launch method: выбираем via SSH  (1 на рис)
Выбираем имя хоста или ip-адрес (2 на рис)
Выбираем наш Credentionals, кторый мы создали ранее (3 на рис - ssh key for agent)

![create-node-next-two](image/create-node-next-two.png)

Далее выберем стратегию верификации, для простоты выберем none
![strategy-verification](image/strategy-verification.png)
Сохраняем агента
>На стенде курса все работает, а локально не получилось создать агента. Возможно когда агент на том же хосте что и Jenkins, нужны другие настройки


Попробуем другой метод:
Launch method:Connecting by controller
И мы видим, что у нас ошибка
![Error-con-for-contr](image/Error-con-for-contr.png)
Заходим в нашу ноду и видим описание ошибки
![Error-con-for-contr-message](image/Error-con-for-contr-message.png)
Это означает, что у нас не включен режим JNLP, включим его
Переходим по ссылке
И включим его, указав порт 50000
![enable-JNLP](image/enable-JNLP.png)
Сохраним и проверим что вссе ОК

И мы видимс, что Jenkins предлагает нам два споосба запуска данного агента

сначала скачиваем наш jar-файл
```curl -sO http://te-nck-lin012.tmh-eng.ru:8090/jnlpJars/agent.jar```
и запускаем его

```
java -jar agent.jar -jnlpUrl http://te-nck-lin012.tmh-eng.ru:8090/computer/firs%2Dnode/jenkins-agent.jnlp -secret 
52ce86e9f0c76dea32efc176514a0fb9d5756a1ea3aaa49eaa54610f42cacf40 -workDir "/home/kenkins"
```

и второй способ с помещением секрета в файл
```
echo 52ce86e9f0c76dea32efc176514a0fb9d5756a1ea3aaa49eaa54610f42cacf40 > secret-file
curl -sO http://te-nck-lin012.tmh-eng.ru:8090/jnlpJars/agent.jar
java -jar agent.jar -jnlpUrl http://te-nck-lin012.tmh-eng.ru:8090/computer/firs%2Dnode/jenkins-agent.jnlp -secret @secret-file -workDir "/home/kenkins"
```

После того как мы создали агента мы можем его использовать в своих pipeline
agent может быть как для stages так и для stage
```
pipeline {
    agent my-agent
    stages {
        stage('gitlab') {
          steps {
             echo 'Notify GitLab'
             updateGitlabCommitStatus name: 'build', state: 'pending'
             updateGitlabCommitStatus name: 'build', state: 'success'
          }        
        }
        stage('compile') {
          agent {
            docker {
              image 'maven:3.9.4-eclipse-temurin-17-alpine' 
              args '-v /root/.m2:/root/.m2' 
            }
          }
          steps {
             echo 'compile'
             sh "mvn clean compile"
          }        
        }
        stage('Build') {
          agent my-next-agent
          steps {
              sh 'mvn -DskipTests clean package' 
          }
        }
    }
}
```

Если нет соединения с агентом по ssh, то попробовать выбрать другую стратегию

![trust-strategy](image/trust-strategy.png)
если и это не помогает, то заходим на страницу логов и слева там будет изображение дискеты, нажимаем на нее и подтверждаем доверие этому соединению

![trasted-ssh](image/trasted-ssh.png)



