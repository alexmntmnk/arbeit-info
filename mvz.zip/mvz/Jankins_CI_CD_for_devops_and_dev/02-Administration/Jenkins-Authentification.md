# Authentification

Это процесс проверки ползьвателя

Авторизация - кикие права ему заведены

Типы Authentification :
- Jenkins own database (стоит по умолчанию (см. 1 на рис))
- LDAP
- Unix config ...

Настройка происходит в Security

И по умолчанию новый пользователь может делать все что угодно (см. 2 на рис)

![Security-auth](image/Security-auth.png)

Предварительно создадим несколько пустых папок и заданий с именами:
1.	qa-services - тип folder
2.	qa-maven - тип job
3.	dev-services - тип folder
4.	dev-agent - тип job

Создадим qa-services - тип folder
Для этого нажимаем New Item

![qa-services](image/qa-services.png)
Далее заходим в qa-services и уже там выбираем New Item, qa-maven - тип job, толлько теперь выбираем как pipeline
![qa-maven](image/qa-maven.png)

Тоже самое повторяем для dev-services and dev-agent

> Для начала работы установим plugin Role-based Authorization Strategy

И на примере этого плагина рассмотрим как мы будем каждой группе давать права на свою папку

Далее Переходим в Manage Jenkins -> Configure Global Security и активируем Role-Base Strategy для Authorization

![Role-Base-Strategy](image/Role-Base-Strategy.png)

Создаем нового пользователя Manage Jenkins -> Manage Users -> Create Users
![create-user](image/create-user.png)
Пробуем зайти в Jenkins с созданным пользователем 
Получаем ошибку об отсутствии прав.
![testUser-access-denide](image/testUser-access-denide.png)

Возвращаемся в Jenkins с правами администратора.
Переходим Manage Jenkins -> Manage and Assign Roles -> Manage Roles

![Manage-and-Assign-Roles](image/Manage-and-Assign-Roles.png)

Добавляем новую роль QA и выдаем права на чтение
![add-role-qa](image/add-role-qa.png)

Переходим Manage Jenkins -> Manage and Assign Roles -> Assign Roles и добавляем нашего пользователя в созданную группу
![Manage-and-Assign-Roles-Assign-Roles](image/Manage-and-Assign-Roles-Assign-Roles.png)

Пробуем зайти в Jenkins с созданным пользователем
Проверяем доступ:

![test-user-login-ok](image/test-user-login-ok.png)

Следующим шагом мы создадим группу, которой будут доступны папки, задания по определенном паттерну в названии
Переходим Manage Jenkins -> Manage and Assign Roles -> Manage Roles в раздел Items
Добавим группу QA, которая может запускать, отменять, читать и проверять workspace у заданий начинающихся с паттерна qa-.* (.*- здесь обозначает любой набор символов)

![add-role-next](image/add-role-next.png)

Переходим Manage Jenkins -> Manage and Assign Roles -> Assign Roles раздел Items и добавляем нашего пользователя в созданную группу

![assign-role-group](image/assign-role-group.png)

Проверяем доступ для нашего пользователя:

![check-access-user](image/check-access-user.png)




