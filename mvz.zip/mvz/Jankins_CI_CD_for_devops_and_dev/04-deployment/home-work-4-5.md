# Задание 4-5

Добавить параллельный deploy на 2 стенда
Директива parallel, позволяет выполнять несколько stage параллельно, что в некоторых случаях значительно ускоряет наш pipeline
Пример:
stage(“Deploy”) {
parallel {
stage(“dev1”) {
steps {*
echo "start deploy on dev1"
}
}
stage(“dev2”) {
steps {*
echo "start deploy on dev2"*
}
}
}
}
 

Решение задачи см. 

[Jenkinsfile-answer-4-5](code/Jenkinsfile-answer-4-5)

