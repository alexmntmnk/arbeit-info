# Задание 4-1

Задача №1
Создать дополнительный pipeline, который будет деплоить наше приложение по ранее выбранному тэгу.
Для параметризации pipeline в jenkins используется секция parameter. Из коробки нам доступны следующие типы параметров
1.	Boolean Parameter определяет логические параметры. Может принимать значения true/false. Также для параметра можно задать значение по умолчанию.booleanParam (name: «DryRun», defaultValue: true, description: «Тестовый запуск»)
2.	String Parameter определяет одностроковый параметр. Поддерживает удаление пробелов с обоих сторон от введённого значения. string (name: «version», defaultValue: «r48», trim: false, description: «Введите версию компонента»)
3.	Multi-line String Parameter определят многостроковый параметр.text (name: «releaseNotes», defaultValue: «none», description: «Описание изменений в релизе»)
4.	Password позволяет определить ввод пароля. Данные пароля не будут отображаться при запуске Job и в console log.password (name: «password», defaultValue: «changeme», description: «Введите пароль»)
5.	Choice Parameter позволяет выбрать несколько параметров из списка ранее предустановленных параметров.choice (name: «env», choices: [«PROD», «DEV», «UAT»], description: «Выберите окружение для установки релиза»)
Пример:
parameters {
booleanParam(name: "dryrun", defaultValue: true, description: "Тестовый запуск")
string(name: "version", defaultValue: "r48", trim: true, description: "Введите версию компонента")
text(name: "releaseNotes", defaultValue: "Добавлены новые feature", description: "Описание изменений в релизе")
password(name: "password", defaultValue: "changeme", description: "Введите пароль")
choice(name: "env", choices: ["PROD", "DEV", "UAT"], description: "Sample multi-choice parameter")
}
Active Choice Parameter
Active Choice Parameter не добавляется по умолчанию. Для его использования сначала нужно установить плагин Active Choices.
Как написано в документации: «Active Choices используется для параметризация Jenkins Job и для создания динамических и интерактивных параметров. Параметры Active Choices могут динамически обновляться и отображаться в виде полей со списком, флажков, переключателей или виджетов пользовательского интерфейса с HTML».

Решение задачи см. 

[Jenkinsfile-answer-4-1](code/Jenkinsfile-answer-4-1)

