# Задание 4-3

В pipeline сборки добавить шаг, вызывающий ранее созданный pipeline deploy
У pipeline есть шаг build, указывая который вы можете начать сборку другого проекта
Пример:
build job: "spring-boot-example-deploy", parameters: [string(name: 'version', value: "$env.BUILD_NUMBER"),string(name: 'env', value: 'DEV')]


Решение задачи см. 

[Jenkinsfile-answer-4-3](code/Jenkinsfile-answer-4-3)


