def example1() {
	println 'Hello from example1'
}

def example2() {
	println 'Hello from example2'
}

return this