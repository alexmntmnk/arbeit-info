# Jenkins Template Engine

Jenkins Template Engine позволяет этим всем управялть, главно что она проще чем Jenkins Shared Library
Прежде всего это проект, вот одни из его примеров структуры
![Jen-Templ-Eng-exam](images/Jen-Templ-Eng-exam.png)

1 - верхнеуровневый каталог с библиотекой
2 - step - шаги нашего pipeline
4 - resource - любые файлы для нашего pipeline
7 - src - тут мы можем опредять общие методы для наших шагов
9 - lib_config - конфигурация библиотеки

Сам проект Jenkins Template Engine лежит в папке
[jenkins-template-engine-main](../jenkins-template-engine-main/)

В папке libraries находятся все наши либы
А вот как выглядит наш компактынй pipoeline
```
node {
checkout()
build()
deploy_to dev  
deploy_to prod 
}
```
Тут Мы так же можем использовать два стиля скриптовой и декларативный

Для работы с ней нам необюходимо установить соотвествубщий плагин Template Engine
После чего переходим 
Manage Jenkins-> System-> Jenkins Templating Engine
Выбираем From SCM
Далее Git 
укажем путь к нашему репозиторию, и как обычно завдем секрет (user/pasw) и укажем его
> Имейте ввиду, что первая вкладака это ручные настройки преекта, нам они не нужны. необходимо нажать клавишу Add и все настройки выполнять тут,см. рис
![Jenkins-Templating-Engine](images/Jenkins-Templating-Engine.png)
Есть одна особенность, по умолчанию путь к библиоткекам это корень, но так как в проекте положили их в папку libraries, то необходиом это указать в настройках

![Jenkins-Templating-Engine-Lib](images/Jenkins-Templating-Engine-Lib.png)

Теперь когда мы создаем pipeline мы видим, что у нас появился еще один тип pipeline: pipeline Template Engine, выбираем его
![Pipeline-Templ-Eng-Git](images/Pipeline-Templ-Eng-Git.png)
Дальше как обычно выбираем git , путь до репы, зададим секреты
Также не забудем указать где у нас храниться кофигурцаия pipeline_config.groovy и Jenkinsfile
![Pipeline-Templ-Eng-Conf](images/Pipeline-Templ-Eng-Conf.png)

Свяжем проект gitlab с Jenkins, как мы делали ранее и запустим его.

Основная идея этой либы в том, что у нас есть любой шаг и при изменении мы просто меняем используемую библиотеку, а шаг остается тот же самый.
Т.е. сам pipeline мы ваще не меняем, а меняем только наш проект


