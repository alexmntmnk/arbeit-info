# Задание 6-2

Дополнительные материалы
Полезные ссылки:
https://plugins.jenkins.io/pipeline-maven/#plugin-content-feature-traceability
https://www.jenkins.io/doc/pipeline/steps/nexus-artifact-uploader/
https://plugins.jenkins.io/email-ext 

