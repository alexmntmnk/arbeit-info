# Задание 6-1


Практика
Перед выполнением домашней работы, необходимо:
в telegram найти бота @botfather и следуя инструкции создаем нового бота. Важно получить токен бота. Токен позволит любому управлять вашим ботом.

![bot-father](images/bot-father.png)


Создаем новый канал и добавляем в него ново-созданного бота с правами админа, нужно для публикации новых сообщений.
Получаем iD чата для отправки уведомлений
Через адресную строку браузера делаем запрос
https://api.telegram.org/bot<TOKEN>/getUpdates
Где меняем <TOKEN> на значение из пункта создания бота.
Ответ на запрос:
{
    "ok": true,
    "result": [
        {
            "update_id": 151985646,
            "channel_post": {
                "message_id": 3,
                "chat": {
                    "id": -1001459789606,
                    "title": "Leroy",
                    "type": "channel"
                },
                "date": 1603123407,
                "text": "/sub",
                "entities": [
                    {
                        "offset": 0,
                        "length": 4,
                        "type": "bot_command"
                    }
                ]
            }
        },
    ]
}
Нужно сохранить chat.id и сохранить знак - перед числом, это полный идентификатор.
Создаем credetial типа SecretText, куда добавляем наш токен
Для разработки и тестирования Jenkins Shared Library нам необходимо установить на свой компьютер gradle. Инструкция по установке — https://gradle.org/install/ 
Далее в рабочем каталоге мы выполняем команду инициализации «gradle init», говорим установщику, что хотим настроить base каталог с groovy-файлами, и получаем готовый проект.
Следующий шаг — создание каталогов для JSL:
1.	var
2.	src
3.	resources
Директория src используется для Groovy классов, которые добавляются в classpath.
Директория resources содержит файлы, которые мы можем загружать в пайплайн.
Директория vars используется в скриптах, которые определяют глобальные переменные, доступные из пайплайна.
Затем заполняем build.gradle, добавляя в него описание наших каталогов:
–--
sourceSets {
  main {
        groovy {
            srcDirs = ['src','vars']
        }
        resources {
            srcDirs = ['resources']
        }
    }
}
—
Для проверки можно создать  простой класс, который увеличивает возраст на указанное значение :)
package com.example
class SampleClass {
   String name
   Integer age
 
   def increaseAge(Integer years) {
      this.age += years
   }
}
 
Подключаем библиотеку:
Осталось дело за малым — подключить библиотеку в Jenkins.
Для этого в Jenkins нужно перейти: Manage Jenkins → Configure System (Настроить Jenkins → Конфигурирование системы). В блоке Global Pipeline Libraries, добавить наш репозиторий:

![create-glob-libr](images/create-glob-libr.png)

Создаем pipeline
@Library('jenkins-shared-library') _
import com.example.SampleClass
pipeline {
    agent any
    stages {
        stage('Demo') {
            steps {
                script {
                    def buddy = new SampleClass()
                    buddy.age = 22
                    buddy.increaseAge(10)
                    echo 'Finally age, is now : ' + buddy.age
                }
            }
        }
    }
}


Решение задачи см. 

[jenkins-shared-library-main](../jenkins-shared-library-main/)

