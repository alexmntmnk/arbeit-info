# Разработка в Jenkins

Цели урока
● Jenkins Template Engine
● Jenkins Shared Library

Для чего они нужны?
До этого мы изучали pipeline, но они решали задачи одного ервиса, а на практике часто их много, и каждый новый добавляет еще одни pipeline.
В итоге их станет 10-20 и все они похожи на друг друга. Поддерживать это становится очень трудно.
И чтобы запустить это все надо зайти в каждый микросервис и запуситить их тогда они пойдут в Jenkins.
Вот примеры pipeline

![Example-01](images/Example-01.png)
![Example-02](images/Example-02.png)
![Example-03](images/Example-03.png)

Для решения этих проблем есть спец инструменты
● Jenkins Template Engine
● Jenkins Shared Library

Они позволяют унифицйироват наши pipeline, т.е. мы сможем менять в однм месте, а меняться будет везде

Основыные шаги по сборке приложения

![Jen-Templ-Eng-Steps](images/Jen-Templ-Eng-Steps.png)
Т.е. каждый шаг мы можем заменить вызовом другого билда из библиотеки
Каждая библиотека это что то общее по смыслу, например
- gitlab - соединение с gitkab
- maven
- gradle
- build

## Jenkins Template Engine

[Jenkins-Template-Engine](Jenkins-Template-Engine.md)


## Jenkins Shared Library

[Jenkins-Shared-Library](Jenkins-Shared-Library.md)


## Домашние задания

Используя Jenkins Shared Library настроить отправку уведомлений об успешности заданий в Telegram

### 1
[home-work-6-1](home-work-6-1.md)

### 2
[home-work-6-2](home-work-6-2.md)

### 3
[home-work-6-3](home-work-6-3.md)

### 4
[home-work-6-4](home-work-6-4.md)