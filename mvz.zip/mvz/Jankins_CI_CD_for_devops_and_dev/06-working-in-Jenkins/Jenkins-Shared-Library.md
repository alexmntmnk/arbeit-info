# Jenkins Shared Library

Эта штука используеться даже чаще, но спикер больше любит Jenkins Template Engine за его простоту
Это библиотека скриптов

Она имеет предопределнную структуру которую нельзя изменять:

![Jenkins-Shared-Library-Struct](images/Jenkins-Shared-Library-Struct.png)

var - это глобальные методы, которые можно вызывать из нашего pipeline

это не вся структура каталогов

Загрузка Shared Library также идет из Git, но можно использовать и локальную загрузку

Сам проект Shared Library лежит в папке
[jenkins-shared-library-main](../jenkins-shared-library-main/)

Она доступупна по умолчанию
Для настройки переходим по адресу
Manage Jenkins-> System-> Global Pipeline Libraries 

![Global-Pipeline-Libraries-add](images/Global-Pipeline-Libraries-add.png)
Задем 
- имя
- укажем ветку, из какой будем получать либу
- укажем репу в git
- секрет (user/passw)

Далее создаем pipeline
без разницы скрипт или SCM (тут все стандартно)

Примеры нескольких pipeline представлены в папке
[jenkins-shared-library-main](../jenkins-shared-library-main/pipeline-example/)




