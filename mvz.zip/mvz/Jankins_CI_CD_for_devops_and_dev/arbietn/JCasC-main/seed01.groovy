folder('folder-a') {
    description('Folder containing all jobs for folder-a')
}
pipelineJob("folder-a/dockerBuild01") {
definition {
    cpsScm {
        scm {
            git{
            remote {
                url("https://gitlab.slurm.io/jenkins/JCasC.git")
                credentials("s043218-dev-gitlab")
            }
            branch("*/main")
            }
        }
        scriptPath("Jenkinsfile-01")
    }
}
}