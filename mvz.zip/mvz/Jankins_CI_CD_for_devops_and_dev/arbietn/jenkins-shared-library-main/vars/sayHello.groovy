def call(String name = 'slurm') {
  echo "Hello, ${name}."
}