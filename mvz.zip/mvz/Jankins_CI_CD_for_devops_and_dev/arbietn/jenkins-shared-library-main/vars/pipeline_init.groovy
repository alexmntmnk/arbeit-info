def call() {
    node('master') { 
         def build_parameters = [:]
            def config

            stage("get args") {
                config = prepare_config()
                currentBuild.displayName = "$config.componentName-$env.BUILD_NUMBER"
                build_parameters["config"] = config.inspect()
                build_parameters["component"] = config.componentName
                build_parameters["gitlabSourceBranch"] = config.gitlabSourceBranch
                build_parameters["gitlabActionType"] = config.gitlabActionType
                echo prepare_config.configToReport(config)
            }
    }
}