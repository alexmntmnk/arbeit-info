import com.example.Gitlab

def call() {
    Gitlab gitlab = new Gitlab(steps)
    def config = [:]
    if (env.gitlabSourceRepoName) {
        println "Pipeline started by webhhook"
        config["buildUser"] = env.gitlabUserName
        
        if (env.gitlabSourceRepoName) {
            config["gitlabActionType"] = gitlabActionType
            config["gitlabSourceRepoHomepage"] = gitlabSourceRepoHomepage
            if (gitlabActionType == "MERGE") {
                config["gitlabMergeRequestIid"] = gitlabMergeRequestIid
            } else {
                config["gitlabMergeRequestIid"] = "not need"
            }
            config["gitlabTargetBranch"] = gitlabTargetBranch
            config["namespace"] = "${env.gitlabSourceNamespace}-${env.gitlabSourceBranch.replace("/", "-").replace(".", "")}".toString().toLowerCase()
            config["gitlabSourceBranch"] = gitlabSourceBranch
            config['componentName'] = gitlabSourceRepoName
            config['gitlabSourceNamespace'] = env.gitlabSourceNamespace

        }
    } else {
        println "Pipeline started by manual job"
        
        config["buildUser"] = currentBuild.rawBuild.getCause(Cause.UserIdCause) ? currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserName() : "jenkins".toString()
        config["namespace"] = env.namespace.toLowerCase()
        config["k8sContext"] = env.cluster
        config["gitlabActionType"] = env.type ? env.type.toString() : "PUSH"
        config["gitlabSourceBranch"] = env.gitlabSourceBranch
        config["gitlabSourceTag"] = env.gitlabSourceTag
        config['componentName'] = component
        config['gitlabSourceNamespace'] = env.project

    }
    def filePath = 'ci/component.yml'.toString()
    def file
    config["gitlabUrl"] = "https://gitlab.slurm.io"
    file = gitlab.getFile("${config.gitlabUrl}", "${config.componentName}", "${config.gitlabSourceBranch}", "${filePath}")
    def yamlData = steps.readYaml text: "$file"
    config["componentBuilder"] = yamlData.component?.builder
    config["databaseEnable"] =  yamlData.database?.enable
    config["databaseName"] = yamlData.database?.name
    config["databaseUsername"] = yamlData.database?.username
    config["databasePassword"] = yamlData.database?.username
    config["kafkaEnable"] =  yamlData.kafka?.enable
    config["kafkaUsername"] = yamlData.kafka?.username
    config["kafkaPassword"] = yamlData.kafka?.username
    config["gitlabRepo"] = config.componentName
    //---//
    config['gitlabSourceBranchUnicode'] =  config.gitlabSourceBranch.replaceAll("/","%2F")
    branchInfo = gitlab.getBranchInfo(config, config.gitlabUrl, config.componentName, config.gitlabSourceBranchUnicode)
    config['gitlabSha'] = branchInfo.commit.id
    config['gtilabShortId'] = branchInfo.commit.short_id
    config['gitlabTitle'] = branchInfo.commit.title
    config['authorEmail'] = branchInfo.commit.author_email
    return config
}


def configToReport(config, showSecret = false) {
    def report = "${'-'.multiply(20)}env:${'-'.multiply(20)}"
    config.each { k, v ->
        def valueForReport = v
        if (showSecret == false && k =~ /((P|p)(a|A)(s|S)(s|S)(w|W)(o|O)(r|R)(d|D))|cert$|((P|p)(a|A)(s|S)(s|S))|((T|t)(o|O)(k|K)(e|E)(n|N))/) {
            valueForReport = "*** SECRET ***"
        
        }
        if (v != null) {
            report += "\n\t${k.toString().padRight(50, '.')}: \"${valueForReport}\""
        }
    }
    return report
}