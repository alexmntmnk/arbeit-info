package com.example

class GlobalVars {
   static String foo = "bar"
}