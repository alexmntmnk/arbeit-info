package com.example
import groovy.text.GStringTemplateEngine
import jenkins.model.*
import groovy.json.JsonSlurperClassic

class Gitlab {
    def data = [:]
    def projectId
    def gitlabToken

def steps
    Gitlab(steps) {
        this.steps = steps
    }
def getFile(String gitlabUrl, String component, String branch, String file) {
    
    steps.echo("${this.getClass()}::getFile: file: $file")
    String encoded = URLEncoder.encode(file.toString(), 'UTF-8')
    steps.echo(gitlabUrl)
    gitlabToken = getToken()
    projectId = this.getProjectID(gitlabUrl, component)
    def connection = new URL("${gitlabUrl}/api/v4/projects/$projectId/repository/files/$encoded?ref=$branch")
            .openConnection() as HttpURLConnection
    connection.setRequestProperty('Accept', 'application/json')
    connection.setRequestProperty('PRIVATE-TOKEN', "${gitlabToken}")
    def json = connection.inputStream.text
    data = new JsonSlurperClassic().parseText(json)
    def properties = new String(data["content"].decodeBase64())
    return properties

}

def getProjectID(String gitlabUrl, String component) {
    gitlabToken = getToken()
    def connection = new URL("${gitlabUrl}/api/v4/projects?search=$component")
            .openConnection() as HttpURLConnection
    connection.setRequestProperty('Accept', 'application/json')
    connection.setRequestProperty('PRIVATE-TOKEN', "$gitlabToken")
    def json = connection.inputStream.text
    data = new JsonSlurperClassic().parseText(json)
    def project = data.find { it.name == component }
    projectId = project.id
    return projectId
}

def getToken(){
    def credentialsId = 'slurm-gitlab-api'
    def creds = com.cloudbees.plugins.credentials.CredentialsProvider.lookupCredentials(
    com.cloudbees.plugins.credentials.common.StandardUsernameCredentials.class, Jenkins.instance, null, null ).find{
    it.id == credentialsId}
    return creds.password
}

def getBranchInfo(args, String gitlabUrl, String component, String branch) {
    projectId = this.getProjectID(gitlabUrl, component)
    gitlabToken = getToken()
    def connection = new URL("${gitlabUrl}/api/v4/projects/${projectId}/repository/branches/${branch}")
            .openConnection() as HttpURLConnection
    connection.setRequestProperty('Accept', 'application/json')
    connection.setRequestProperty('PRIVATE-TOKEN', "${gitlabToken}")
    def json = connection.inputStream.text
    data = new JsonSlurperClassic().parseText(json)
    steps.echo("${this.getClass()}::getBranchInfo: branch: $branch")
    return data

}

}