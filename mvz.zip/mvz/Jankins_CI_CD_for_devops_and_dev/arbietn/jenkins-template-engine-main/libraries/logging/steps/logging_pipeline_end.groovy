@CleanUp
void call(hookContext){
    println "End log event of the pipeline!" 
}
