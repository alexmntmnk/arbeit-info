@Init 
void call(hookContext){
    println "Start log event for beginning of the pipeline!" 
}
