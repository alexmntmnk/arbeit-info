package logging

class Utility implements Serializable{
  void doThing(steps){
    steps.echo "message from the Utility class"
  }
}