void call(){
        stage("Git: Checkout"){
                git branch: 'main', credentialsId: 's043218-dev-gitlab', url: 'https://gitlab.slurm.io/jenkins/spring-boot-rest-example.git'
        }
}
