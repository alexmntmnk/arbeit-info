https://docs.gitlab.com/ee/integration/jenkins.html



!!! При настройке интеграции с gitlab обязательно добавить адрес jankins в белый список
Filtering outbound requests
https://docs.gitlab.com/ee/security/webhooks.html#allow-outbound-requests-to-certain-ip-addresses-and-domains



Для интеграции необходимо:
1. Настроить сервер Jenkins
Configure the Jenkins server
Install and configure the Jenkins plugin to authorize the connection to GitLab.

On the Jenkins server, select Manage Jenkins > Manage Plugins.
Select the Available tab. Search for gitlab-plugin and select it to install. See the Jenkins GitLab documentation for other ways to install the plugin.
Select Manage Jenkins > Configure System.
In the GitLab section, select Enable authentication for ‘/project’ end-point.
Select Add, then choose Jenkins Credential Provider.
Select GitLab API token as the token type.
In API Token, paste the access token value you copied from GitLab and select Add.
Enter the GitLab server’s URL in GitLab host URL.
To test the connection, select Test Connection.


2.
Создать проект в Jenkins
Если выбрали pipeline , то необходимо довавить код
pipeline {
    agent any

    stages {
       stage('gitlab') {
          steps {
             echo 'Notify GitLab'
             updateGitlabCommitStatus name: 'build', state: 'pending'
             updateGitlabCommitStatus name: 'build', state: 'success'
          }
       }
    }
 }
 
 
3. Далее натроим 
Configure the GitLab project
Configure the GitLab integration with Jenkins in one of the following ways.

With a Jenkins server URL
You should use this approach for Jenkins integrations if you can provide GitLab with your Jenkins server URL and authentication information.

On the left sidebar, select Search or go to and find your project.
Select Settings > Integrations.
Select Jenkins.
Select the Active checkbox.
Select the events you want GitLab to trigger a Jenkins build for:
Push
Merge request
Tag push
Enter the Jenkins server URL.
Optional. Clear the Enable SSL verification checkbox to disable SSL verification.
Enter the Project name. The project name should be URL-friendly, where spaces are replaced with underscores. To ensure the project name is valid, copy it from your browser’s address bar while viewing the Jenkins project.
If your Jenkins server requires authentication, enter the Username and Password.
Optional. Select Test settings.
Select Save changes.


Расмомтрим подробнее создания Items с интеграцией Gitlab


1. Создаем секрет (Credentional), для чего заходжим на страницу
Manage Jenkins-> Credentional
и создаем секрет, указывая токен доступа из Gitlab
2. Настроим соединение с Gitlab, см. описание в документации выше, для чего заходжим на страницу
Manage Jenkins-> System
секция Gitlab
![Credentials-gitlab](images/Credentials-gitlab.png)
Тут мы задем имя соединения (например gitlab-jen), указываем хост и наш секрет из пред пункта
3. Создаем новый item типа pipeline
4. на странице его параметров выставляем следующие
Тут мы выбираем имя соединения из пред пункта
![step-one](images/step-one.png)
и
![step-two](images/step-two.png)
не забывыем настроить сам pipeline
![step-three](images/step-three.png)
а так же указать нужные ветки и имя скриптового файлда Jenkinsfile
![step-four](images/step-four.png)

Сохраняем наш pipeline

