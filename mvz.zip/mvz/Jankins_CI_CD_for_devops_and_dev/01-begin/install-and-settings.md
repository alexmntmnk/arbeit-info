
Jankins - это Java app, поэтому сначала необходимо уставновить Java, рекомендуется 11 версия

app-install openjdk-11-headless

Для начала надо откорректировать лимиты, чтобы пайплайн не звавис во время выполнения
Для этого переходим на
```sudo nano /etc/security/limits.conf```

Добавим в конец файла
```
jenkins      soft     core    unlimited
jenkins      hard     hard    unlimited
jenkins      soft     fsize   unlimited
jenkins      soft     fsize   unlimited
jenkins      soft     nofile  4096
jenkins      hard     nofile  8192
jenkins      soft     nproc   30654
jenkins      hard     nproc   30654 
```
т.е. мы добавили пользолвателю jenkins права на различные лимиты

Также важно настроить фаервол на машине
jenkins использует два порта 8080 и 50000

Установим фаервол и настроим его
```
sudo apt-get install ufw
sudo ufw allow OpenSSH
sudo ufw allow 8080
sudo ufw enable
```
Установка Jenkins
Добавляем Jenkins repository
```
wget -q -O - https://pkg.jenkins.io/debian-stable/jenkins.io.key |sudo gpg --dearmor -o /usr/share/keyrings/jenkins.gpg
sudo sh -c 'echo deb [signed-by=/usr/share/keyrings/jenkins.gpg] http://pkg.jenkins.io/debian-stable binary/ > /etc/apt/sources.list.d/jenkins.list'
```
Устанавливаем Jenkins
```
sudo apt-get update
sudo apt-get install jenkins -y
systemctl status jenkins
systemctl enable jenkins
```

Т.к. Jenkins очень требовательный к памяти, то необходимо Конфигурируем дополнительным Java параметры JVM:
```
sudo vi /lib/systemd/system/jenkins.service
```

Добавляем:

```
Enviroment ="JAVA_OPTS=-Djava.awt.headless=true -XX:+AlwaysPreTouch -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/lib/jenkins/log -XX:+UseG1GC -XX:+UseStringDeduplication -XX:+ParallelRefProcEnabled -XX:+DisableExplicitGC -XX:+UnlockDiagnosticVMOptions -XX:+UnlockExperimentalVMOptions -Xlog:gc=info,gc+heap=debug,gc+ref*=debug,gc+ergo*=trace,gc+age*=trace:file=/var/lib/jenkins/gc.log:utctime,pid,level,tags:filecount=2,filesize=100M -Xmx512m -Xms512m*"
```
При этом предыдущее содержимое JAVA_OPTS можно удалить и полностью заменить новым

Примечание -Xmx512m -Xms512m устанавливаем в зависимости от доступной памяти на  виртуальной машине
Обычно выделяют не более 16 Ггб, при условии, что на машине не менее 32Ггб

-Xmx512m -Xms512m  - этого хватит для тестовых заданий, , вроде как оно идет по умолчанию, на практике желательно его увеличивать


После установки необходимо задать токен, 
его можно использовать для доступа по ssh 

Если нет доступа по ssh, Перезагризить Jenkins можно из строки браузера, добавив в путь restart - жесткая перезагрузка не дожидаясь выполнения джобов, 
рекомендуестя исползовать safeRestart


Посмотреть все эти опции можно командой
```systemctl status jenkins```
см. ниже ее вывод

Если измениения не в файле /lib/systemd/system/jenkins.service не пройдут, то можно попробовать способ
Для этого запускаем
```systemctl edit jenkins```
там правим, он создает файл override.conf и после перезапуска он перезапишет файл /lib/systemd/system/jenkins.service
Проверим, что они применились 
```systemctl status jenkins```



Дебиан
/lib/systemd/system/jenkins.service

Красная Шапка
/usr/lib/systemd/system/jenkins.service

openSUSE
/usr/lib/systemd/system/jenkins.service

Основной сервисный блок доступен только для чтения и не предназначен для редактирования вручную. В верхней части файла содержится большое уведомление, напоминающее пользователю, что он доступен только для чтения.

Значения могут быть переопределены в раскрывающемся модуле ( override.confфайле) для службы. Отредактируйте встраиваемый блок с помощью:

# systemctl edit jenkins
Файл override.confхранится по адресу /etc/systemd/system/jenkins.service.d/override.confи может использоваться для настройки службы. Обратите внимание, что такие настройки должны быть выполнены в [Service]разделе, чтобы они вступили в силу. Пример содержимого файла override.confможет включать:

[Unit]
Description=My Company Jenkins Controller

[Service]
# Add JVM configuration options
Environment="JAVA_OPTS=-Djava.awt.headless=true -XX:+UseStringDeduplication"

# Arbitrary additional arguments to pass to Jenkins.
# Full option list: java -jar jenkins.war --help
Environment="JENKINS_OPTS=--prefix=/jenkins --javaHome=/opt/jdk-17"

# Configuration as code directory
Environment="CASC_JENKINS_CONFIG=/var/lib/jenkins/configuration-as-code/"
systemctl edit jenkinsсоздает встраиваемый модуль, как и в случае с разрешениями root0644 ( ). -rw-r—​r--С другой стороны, логика миграции создает встраиваемый модуль, как и rootв случае с разрешениями 0600 ( -rw-------). Это может иметь последствия, если вы сохраняете местоположение хранилища ключей и/или пароль HTTPS во встраиваемом модуле, а также запускаете задания непосредственно на контроллере, что в проекте Jenkins явно не рекомендуется . Если у вас есть сомнения, защитите подключаемый модуль, установив для него права доступа 0600 с помощью chmod(1).
Встраиваемый модуль объединяет конфигурацию всех трех дистрибутивов: Debian, Red Hat и openSUSE. Также обратите внимание, что встраиваемый модуль не перезаписывается при обновлении.

В отличие от конфигурации System V init(8), override.confфайл содержит только настройки, а не исходные значения по умолчанию. Пользователи, привыкшие редактировать существующий набор значений по умолчанию, должны одновременно обращаться к служебному блоку (только для чтения) при редактировании встраиваемого модуля или использовать команду типа , которая копирует исходный служебный модуль вместо systemctl edit jenkins --fullсоздания вставной блок.
Редактирование подключаемого модуля с помощью systemctl edit jenkinsавтоматически перезагрузит systemd(1)конфигурацию. Настройки вступят в силу при следующем перезапуске Jenkins. Если вы редактируете раскрывающийся модуль без systemctl(1), вам нужно запустить его systemctl daemon-reload, чтобы изменения вступили в силу.

И последнее, что следует упомянуть о сервисном модуле, — это использование им спецификаторов, которые могут быть незнакомы некоторым пользователям. Вставной блок не выполняет расширение корпуса. Спецификаторы могут вставлять контекстную информацию (например, имя хоста системы, имя модуля и версию ядра операционной системы) в встраиваемый модуль. В systemd(1)документации есть таблица спецификаторов, доступных в юнит-файлах .

Запуск служб
systemdПосле определения службы Jenkins ее можно запустить с помощью:

# systemctl start jenkins
Если Jenkins не сигнализирует о завершении запуска в течение настроенного времени, служба будет считаться неудавшейся и будет снова отключена. На каждом этапе инициализации (например, «Начала инициализация», «Перечислены все плагины», «Подготовлены все плагины», «Запущены все плагины», «Дополнены все расширения», «Конфигурация системы загружена», «Конфигурация системы адаптирована», «Загружена»). все задания», «Конфигурация для всех заданий обновлена» и «Инициализация завершена»), время ожидания увеличивается на значение системного jenkins.model.Jenkins.extendTimeoutSecondsсвойства (по умолчанию 15 секунд). Тайм-аут можно настроить с помощью TimeoutStartSecдирективы в сервисном модуле.

Остановка служб
Службу Jenkins systemdможно остановить с помощью:

# systemctl stop jenkins
Перезапуск служб
Службу Jenkins systemdможно перезапустить с помощью:

# systemctl restart jenkins
Перезагрузка определений служб
После внесения изменений в файлы конфигурации может потребоваться перезагрузка определения службы с помощью:

# systemctl daemon-reload
Чтение журналов обслуживания
Журналы службы Jenkins можно прочитать командой:

journalctl -u jenkins
Удаление журналов службы
Файлы журналов, хранящиеся в системе, systemdобычно настроены на автоматическую ротацию. Если файлы журнала необходимо уменьшить в размере, используйте команду:

journalctl --vacuum-size=500M
Просмотр статуса услуги
Статус службы Jenkins systemdможно просмотреть с помощью systemctl status jenkins. Некоторые примеры показаны ниже.

После обновления плагинов:

systemctl status jenkins
● jenkins.service - Jenkins Continuous Integration Server
     Loaded: loaded (/lib/systemd/system/jenkins.service; enabled; vendor preset: enabled)
    Drop-In: /etc/systemd/system/jenkins.service.d
             └─override.conf
     Active: active (running) […]
   Main PID: […] (java)
     Status: "Restart in 10 seconds"
Когда Дженкинса сбивают:

systemctl status jenkins
● jenkins.service - Jenkins Continuous Integration Server
     Loaded: loaded (/lib/systemd/system/jenkins.service; enabled; vendor preset: enabled)
    Drop-In: /etc/systemd/system/jenkins.service.d
             └─override.conf
     Active: deactivating (stop-sigterm) since […]
   Main PID: […] (java)
     Status: "Stopping Jenkins"
Когда Дженкинс запускается:

systemctl status jenkins
● jenkins.service - Jenkins Continuous Integration Server
     Loaded: loaded (/lib/systemd/system/jenkins.service; enabled; vendor preset: enabled)
    Drop-In: /etc/systemd/system/jenkins.service.d
             └─override.conf
     Active: activating (start) since […]
   Main PID: […] (java)
После успешного запуска:

systemctl status jenkins
● jenkins.service - Jenkins Continuous Integration Server
     Loaded: loaded (/lib/systemd/system/jenkins.service; enabled; vendor preset: enabled)
    Drop-In: /etc/systemd/system/jenkins.service.d
             └─override.conf
     Active: active (running) since […]
   Main PID: […] (java)


Интеграция с Gitlab
[Gitlab integration](Gitlab-integration.md)
