# Лучшие практики в Jenkins

> Ко всем Best Practics стоит относиться с отсрожностью
Т.е. это не всегда то что гадо внедрять в твоем проекте, и он должен быть адаптирован под это решение


## Docker Slave

[Docker-Slave](Docker-Slave.md)
    

## Kubernate Slave

Kubernate-Slave.md

[Kubernate-Slave](Kubernate-Slave.md)

## backup

[backup](backup-jenkins.md)

## Configuration-As-Code

![Configuration-As-Code](Configuration-As-Code.md)

