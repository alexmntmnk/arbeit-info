# Задание 5-3

Задача №3
Настроить интеграцию проекта с Sonarqube, блокировать pipeline при нарушении Quality Gate
Для работы с Sonarqube, необходимо установить plugin SonarQube Scanner for Jenkins

Для начала работы получаем token пользователя в sonarqube, для этого в web-интерфейс Sonarqube переходим в Administration -> Security -> Users

![pic-3-1](images/pic-3-1.png)

Далее создаем credential, типа Secret Text в Jenkins, где  secret - полученный token. Заходим в Configure System и настраиваем сервер SonarQube, вводим произвольное имя и адрес сервера, также выбираем созданный на прошлом шаге пароль.

![pic-3-2](images/pic-3-2.png)

К нашему pipeline добавляется дополнительный сниппет withSonarQubeEnv, которому достаточно передать только имя нашего сервера
withSonarQubeEnv(installationName: 'sq') {
                       //code block
                   }
Для проверки статуса QualityGate используется шаг:
waitForQualityGate, к которому мы можем дополнительно указать abortPipeline: true  - прерывать pipeline, при несоблюдении проверок кода



Решение задачи см. 

[Jenkinsfile-answer-5-3](code/Jenkinsfile-answer-5-3)

