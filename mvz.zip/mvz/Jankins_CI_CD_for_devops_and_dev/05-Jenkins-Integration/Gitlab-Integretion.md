# Gitlab-Integretion

● Запуск по событию ( push, merge ) с помощью webHook
● Статусы сборок в gitlab - отправка из Jenkins в gitlab
● Дополнительный контроль

Для этого есть два плагина
gitlab-plugin
gitlab-braunch-source-plugin

Интеграцию начинаем с установки плагинов
Далее надо создать New credentials
Для чего идем в Manage Jenkins-> Credentional->New credentials
Плагин gitlab-braunch-source-plugin добавляет возможность создания такого токена в jenkins

![New-credentials.png](images/New-credentials.png)
При этом токен вставляем из Gitlab-Access token пользователя

Далее создаем коннектор для gitlab
Для чего идем Manage Jenkins-> System-> Gitlab
Задаем ему имя, указжим где рассположен сервер gitab и узажем наш токен
Для своего проекта я задавал настройки в этой секции, но при этом соединение я настраивал через Integration, а не через WebHook
![Gitlab-connections](images/Gitlab-connections.png)
Ниже есть еще настройка сервера, на курсе мы настраивали именно ее и соединение настраивали через WebHook
Jenkins-> System-> Gitlab Server
В этой части все настроки те же самые
![gitlab-server-01](images/gitlab-server-01.png)
А вот тут мы еще ставим галочку, чтьо будем использовать WebHook, при этом в поле токен ни чего не прописываем
![gitlab-server-02](images/gitlab-server-02.png)

Так же заведем еще один Credentional - userName-Password (ранее есть пример как это делать)

Далее создаем новый pipeline
Но при этом мы выбираем не обычный pipeline, а MultiBranchPipeline

тут мы в Branch Sources выбираем сначала gitlab? затем наш Gitlab-Server, который мы сконфигурили выше, далее выбираем наш Credentional (user-password)
![MultiBranchPipeline-01](images/MultiBranchPipeline-01.png)

Далее выбираем группу проектов в Gitlabe и ниже выбираем наш проект из списка подгруженных, которые есть в указанной выше группе

![MultiBranchPipeline-02](images/MultiBranchPipeline-02.png)

Далее выбираем стратегию веток которые мы будем сканить, тут три варианта, все ветки, ветки только мастер и девелоп, тут можно сделать много настроек с помощью регулярок
Мы выберем только ветки с мерж реквестами, остальные настройки трогать не будем и оставим как есть

![MultiBranchPipeline-03](images/MultiBranchPipeline-03.png)

Как это работает, он проходит все наши ветки и ищет там Jenkinsfile, если он его находит, то помечает его для сборки
В нашем примере находит ветку main берет из негои запускает сборку.
В настройках ниже есть секция для поиска новых веток и запуска по условию/событию
Но так же можно настроить в gitlab WebHook для запуска по условию/событию

> WebHook - это просто post запрос в сторону Jenkins

















[Jenkinsfile](code/Jenkinsfile)