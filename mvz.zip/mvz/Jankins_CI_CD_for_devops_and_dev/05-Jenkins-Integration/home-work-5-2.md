# Задание 5-2

Задача №2
Отключить хранение java артефактов и добавить к pipeline статистику по юнит-тестам, установить для mvn - Xmx
Для начала работы, устанавливаем плагин “Pipeline Maven Integration”

После установки у нас появляется дополнительный сниппет внутри steps
withMaven - любая команда mvn выполненная внутри данного блока будет обработана withMaven wrapper
У нас имеется возможность передавать дополнительные опции, например:
mavenSettingsConfig - id settings.xml файла из ConfigFileProvider
mavenLocalRepo - путь до локального репозитория
maven - версия maven, объявленная в Tools
mavenOpts - дополнительные опции mvn, такие как XmX, XmS, настройки прокси и другие
Также withMaven, предлагает возможности работы c jar файлами полученными в результате выполнения pipeline и результатами тестов.
Для этого необходимо сконфигурировать доп опции:
artifactsPublisher(disabled: true) - публикация jar файлов
Полный список опции можно посмотреть на сайте plugin https://www.jenkins.io/doc/pipeline/steps/pipeline-maven/


Решение задачи см. 

[Jenkinsfile-answer-5-2](code/Jenkinsfile-answer-5-2)

