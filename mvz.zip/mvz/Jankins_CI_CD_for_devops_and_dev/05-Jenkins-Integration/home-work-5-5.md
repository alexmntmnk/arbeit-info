# Задание 5-5

Задача №5
Настроить нотификацию по email о успешном прохождении pipeline
Для отправки уведомлений необходимо установить plugin Email Extension Plugin
https://plugins.jenkins.io/email-ext/
Предварительно настраиваем секцию Extended E-mail Notification, пример настройки на скриншоте.
Также не забываем, что для успешной отправки сообщений необходимо чтобы адрес отправителя совпадал с опцией System Admin e-mail address

![pic-5-1](images/pic-5-1.png)

В pipeline появляется сниппет emailext c опциями. Вот основные из них
subject : тема письма
body : содержимое письма, принимаем формат html
attachLog : прикрепление лога pipeline  к письму
compressLog : архивировать лог или нет
recipientProviders: добавление получателей ( buildUser, developers)
to : получатель
Пример использования:
emailext body: 'SUCCESS', subject: 'Maintenance finished', to: 'kirill.borisovoff@yandex.ru'  


Решение задачи см. 

[Jenkinsfile-answer-5-5](code/Jenkinsfile-answer-5-5)

