# Интеграции Jenkins

Цели урока
● Интеграция с gitlab
● Интеграция с maven
● SonarQube интеграция
● Интеграция с artifactory Nexus
● Отправка уведомлений

## Gitlab-Integretion

[Gitlab-Integretion](Gitlab-Integretion.md)


## Maven

[Maven-Integretion](Maven-Integretion.md)

## Sonarqube

[Sonarqube-Integretion](Sonarqube-Integretion.md)


## Email

[Email-Integretion](Email-Integretion.md)

## Nexus

[Nexus-Integretion](Nexus-Integretion.md)


## Домашние задания
Для выполнения домашней работы вам потребуется установленный сервер Jenkins. Репозиторий с java приложением, например https://github.com/silabeer/
spring-boot-rest-example. А так установленный сервер SonarQube и Nexus

### 1
[home-work-5-1](home-work-5-1.md)

### 2
[home-work-5-2](home-work-5-2.md)

### 3
[home-work-5-3](home-work-5-3.md)

### 4
[home-work-5-4](home-work-5-4.md)

### 5
[home-work-5-5](home-work-5-5.md)

