# Maven-Integretion

Плагин - тоже самое, что и
```mvn clean install```
Установим этот плагин
```pipeline maven integration```
Интрумент для сборки Java проекта:
компиляции, создания jar, создания дистрибутива
программы, генерации документации
withMaven() {
// some block
}

Рассмотрим на примере

[Jenkinsfile-withMaven](code/Jenkinsfile-withMaven)

Этот плагин умеет выводить все наши тесты на отдельную вкладку с подробной инфой о каждом тесте

## Хранение файлов

Например нам необходимо в maven выставить какие-то настройки в файцле maven-setting.xml
Конечно можно сохранить этот файл в git и вычитывать его, ложить в локальную папу .m2
Но это не очень хорошо с точки зрения безопасности открыто хранить секреты
Для это в Jenkins есть File Management 
Посмотрим что там есть
Manage Jenkins-> Managemend File

Config File Management.png

![ConfigFileManagement](images/ConfigFileManagement.png)
Кроме того у нас есть набор предустановленых файлов

![NewConfigFiles](images/NewConfigFiles.png)
Выберем Maven settings.xml, зададим ему тэг и jenkins австоматом создаст базовый конфиг-файл maven

> Есть также Global Maven settings.xml, но это для всех Pipeline

Теперь нами надо добавить его в наш Pipeline, делается это очень просто, нам нужно указать опцию , mavenSettingConfig: 'my-project', указав ему id
см. новый файл

[Jenkinsfile-withMavenSetting](code/Jenkinsfile-withMavenSetting)

У данного плагина есть еще много опций, включая публикацию тестов отправку их по email и др.
Так же можно добавить память maven, в случае если ее вдруг не хватит.
Селать это моно след образом
Добавим в проект переменную AUDITIONAL_MVN_OPTS = 'Xmx1G'
есть дирректива которая позволяет добавить эту опцию в конфиг maven mavenOpts
см.

[Jenkinsfile-withMavenOpts](code/Jenkinsfile-withMavenOpts)
Обычно на проектах отключают артефакты, делается это вот так

[Jenkinsfile-withMavenArtifact](code/Jenkinsfile-withMavenArtifact)




