# Задание 5-1

Задача №1
Интеграция с gitlab. Организовать сборку по commit в репозиторий. Настроить получение gitlab-ом статуса pipeline
Для начала работы, устанавливаем плагин “Gitlab”

![pic-1-1](images/pic-1-1.png)
После установки, необходимо перезапустить Jenkins ( соответствующая галочка при установке plugin)
Перейдем в конфигурацию job сборки, там появилась дополнительная опция:

![pic-1-2](images/pic-1-2.png)


Идём в gitlab и устанавливаем webhook

![pic-1-3](images/pic-1-3.png)

Делаем тестовый запуск и получаем ошибку 403
Создаем для пользователя token

![pic-1-4](images/pic-1-4.png)

Изменяем адрес webhook -> http://username:token@<webhook url from job>
Для получения gitlab статуса pipeline, создаем персональный token в gitlab и в настройках Jenkins добавляем gitlab server

![pic-1-5](images/pic-1-5.png)


Секция option в pipeline пополняется новой опцией:
gitLabConnection - позволяет наш в рамках одного Jenkins, работать с несколькими инсталяциями gitlab, указывая для каждого pipeline нужную
Пример:
options {
      gitLabConnection('edu.slurm')
    }
Секция trigger пополняется опцией: gitlab - позволяет настраивать trigger по событию из gitlab
Пример:
triggers {
        gitlab(triggerOnPush: true, triggerOnMergeRequest: true, branchFilterType: 'All')
  }
Директивы для использования в pipeline:
gitlabCommitStatus - позволяет уведолмять gitlab о шагах сборки
Пример:
stage("unit test") {
   steps {
           gitlabCommitStatus(name: 'unit test') {
echo ‘Unit test’
}
   }
}
updateGitlabCommitStatus - повзоляет уведомлять giltab о статусе pipeline
Пример:
updateGitlabCommitStatus name: 'build', state: 'pending'


Решение задачи см. 

[Jenkinsfile-answer-5-1](code/Jenkinsfile-answer-5-1)

