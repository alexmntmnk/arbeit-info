# Email-Integretion

Email - это не отемлемая часть интеграции. Постоянно необходимо отправлять различные события сборки, прошла - не прошла.
Поэтому надо уметь это настроить.

Есть дефолтные реализации.
Но лучше установить плагин.
EmailExtionsPlugin
Настроим его на пример почты на Yandex
Manage Jenkins-> System-> Email Extendions
![Email-Ext-01](images/Email-Ext-01.png)
Укажем сервер smtp порт
Далее создадим секрет в Jenkins (user/password - их берем из настроек почты для smtp)
Открываем Advanset и выбираем наш секрет
И обязательно установить галочку used SSL:
![Email-Ext-02](images/Email-Ext-02.png)
Посмотрим как это работает:

[Jenkinsfile-Email](code/Jenkinsfile-Email)

Для данного пойплайна моно включить опцию Enabke debug log для поиска более серьезных ошибок
![enable-debug-log](images/enable-debug-log.png)




