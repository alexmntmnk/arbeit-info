# Задание 5-4

Задача №4 
Настроить публикацию docker image и java-артефактов в Nexus
Для работы необходимо установить plugin nexusArtifactUploader
Заходим в Nexus UI, добавляем пользователя jenkins, выдаем ему нужные права, мы используем права nx-admin. Ни в коем случае не делайте так в production :)


![pic-4-1](images/pic-4-1.png)


Конфигурируем maven репозиторий типа Release

![pic-4-2](images/pic-4-2.png)


Создаем необходимый credential типа username/password в Jenkinsё
После установки появляется сниппет nexusArtifactUploader
Пример:
nexusArtifactUploader(
                           nexusVersion: <nexus3 or nexus2>,
                           protocol: <http or https>,
                           nexusUrl: <nexus url>,
                           groupId: <e.g com.example>,
                           version: <eg 2.0.0>,
                           repository: <repo name e.g maven-local>,
                           credentialsId: <jenkins credentials id>,
                           artifacts: [
                              [artifactId: pom.artifactId,
                               classifier: '',
                               file: artifactPath,
                               type: pom.packaging]
]

Для публикации docker image предварительно создаем repo 

![pic-4-3](images/pic-4-3.png)


Используем  сниппет docker.withRegistry указывая адрес нашего локального registry
Важно: в качестве адреса docker registry используем Ip:port


Решение задачи см. 

[Jenkinsfile-answer-5-4](code/Jenkinsfile-answer-5-4)

