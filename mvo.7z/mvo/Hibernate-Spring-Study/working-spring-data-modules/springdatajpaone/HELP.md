# Starting a new Spring Data JPA project

Для демонстрации и анализа возможностей Spring Data JPA Мы будем использовать тот же пример приложения CaveatEmptor
И в качестве базового поставщика JPA будем использовать Hibernate
В этой части будем использовать скрипт Ch04.sql docker-compose Тот же самый

У нас есть один класс User и UserRepository

> CrudRepository - это универсальный, не зависящий от технологии интерфейс сохранения, который мы можем использовать не только для JPA / реляционных баз данных, но и для Базы данных NoSQL. Например, мы можем легко изменить базу данных с MySQL на MongoDB, не затрагивая реализацию, изменив зависимость с исходного spring-boot-starter-data-jpa на spring-boot-starter-data-mongodb.

Все настройки БД прописаны в application.properties
Запустим приложение:
'''mvn spring-boot:run'''
