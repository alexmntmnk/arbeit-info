package com.alex.study.hibernatespring.springdatajpaone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringdatajpaoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
