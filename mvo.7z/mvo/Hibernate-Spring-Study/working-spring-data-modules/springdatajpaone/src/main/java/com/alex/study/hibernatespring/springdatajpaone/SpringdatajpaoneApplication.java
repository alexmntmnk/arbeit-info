package com.alex.study.hibernatespring.springdatajpaone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDate;
import java.time.Month;

import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;

import com.alex.study.hibernatespring.springdatajpaone.model.User;
import com.alex.study.hibernatespring.springdatajpaone.repositories.UserRepository;

@SpringBootApplication
public class SpringdatajpaoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringdatajpaoneApplication.class, args);
	}

	@Bean
	public ApplicationRunner configure(UserRepository userRepository) {
		return env ->
		{
			System.out.println("ApplicationRunner");
			
			User user1 = new User("beth", LocalDate.of(2020, Month.AUGUST, 3));
			User user2 = new User("mike", LocalDate.of(2020, Month.JANUARY, 18));

			userRepository.save(user1);
			userRepository.save(user2);

			userRepository.findAll().forEach(System.out::println);
		};
	}

}
