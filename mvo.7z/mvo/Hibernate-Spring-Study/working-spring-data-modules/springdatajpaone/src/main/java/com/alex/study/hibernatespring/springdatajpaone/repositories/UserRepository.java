package com.alex.study.hibernatespring.springdatajpaone.repositories;

import org.springframework.data.repository.CrudRepository;

import com.alex.study.hibernatespring.springdatajpaone.model.User;

public interface UserRepository extends CrudRepository<User, Long> {
}
