package com.alex.study.hibernatespring.springdatajpatwo.model;

import org.springframework.beans.factory.annotation.Value;

public class Projection {

    public interface UserSummary {

        // создадим закрытую проекцию — это интерфейс, все геттеры которого соответствуют свойствам целевого 
        // объекта. Когда вы работаете с закрытой проекцией, выполнение запроса может быть оптимизировано 
        // Spring Data JPA, поскольку все свойства, необходимые прокси-серверу проекции, известны с 
        //самого начала.
        String getUsername();

        // создаем открытую проекцию, которая является более гибкой. Однако Spring Data JPA не сможет 
        // оптимизировать выполнение запроса, поскольку выражение SpEL вычисляется во время выполнения 
        @Value("#{target.username} #{target.email}")
        String getInfo();

    }

    public static class UsernameOnly {
        private String username;

        public UsernameOnly(String username) {
            this.username = username;
        }

        public String getUsername() {
            return username;
        }

    }

}
