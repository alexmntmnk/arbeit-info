package com.alex.study.hibernatespring.springdatajpatwo;

import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Sort;

import com.alex.study.hibernatespring.springdatajpatwo.model.User;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class DeleteQueryTest extends SpringdatajpatwoApplicationTests {

    @Test
    void testDeleteByLevel() {
        userRepository.deleteByLevel(2);
        List<User> users = userRepository.findByLevel(2, Sort.by("username"));
        assertEquals(0, users.size());
    }

    @Test
    void testDeleteBulkByLevel() {
        userRepository.deleteBulkByLevel(2);
        List<User> users = userRepository.findByLevel(2, Sort.by("username"));
        assertEquals(0, users.size());
    }
}
