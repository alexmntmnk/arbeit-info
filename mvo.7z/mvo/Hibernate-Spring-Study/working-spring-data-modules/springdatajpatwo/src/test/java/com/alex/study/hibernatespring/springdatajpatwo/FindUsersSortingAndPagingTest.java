package com.alex.study.hibernatespring.springdatajpatwo;

import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import com.alex.study.hibernatespring.springdatajpatwo.model.User;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class FindUsersSortingAndPagingTest extends SpringdatajpatwoApplicationTests {

    @Test
    void testOrder() {

        User user1 = userRepository.findFirstByOrderByUsernameAsc();
        User user2 = userRepository.findTopByOrderByRegistrationDateDesc();
//        Page<User> userPage = userRepository.findTop3ByActive(true, PageRequest.of(1, 3));
        // Найти всех пользователей, разделите их на страницы и верните номер страницу 1 размером 3, т.е. 
        // 3 записи на странице (нумерация страниц начинается с 0).
        Page<User> userPage = userRepository.findAll(PageRequest.of(1, 3));
        // Найдите первых двух пользователей со 2-м уровнем, упорядоченных по дате регистрации
        List<User> users = userRepository.findFirst2ByLevel(2, Sort.by("registrationDate"));

        assertAll(
                () -> assertEquals("beth", user1.getUsername()),
                () -> assertEquals("julius", user2.getUsername()),
                () -> assertEquals(2, users.size()),
                () -> assertEquals(3, userPage.getSize()),
                () -> assertEquals("beth", users.get(0).getUsername()),
                () -> assertEquals("marion", users.get(1).getUsername())
        );

    }

    @Test
    void testFindByLevel() {
        // Тип sort расширяет сортировку и может использовать дескрипторы методов для определения свойств 
        // для сортировки
        Sort.TypedSort<User> user = Sort.sort(User.class);

        // Найдите пользователей 3-го уровня и отсортируйте по дате регистрации в порядке убывания.
        List<User> users = userRepository.findByLevel(3, user.by(User::getRegistrationDate).descending());
        assertAll(
                () -> assertEquals(2, users.size()),
                () -> assertEquals("james", users.get(0).getUsername())
        );

    }

    @Test
    void testFindByActive() {
        // м активных пользователей, отсортированных по дате регистрации, разделим их на страницы и 
        // вернем страницу с номером 1 размером 4 (нумерация страниц начинается с 0).
        List<User> users = userRepository.findByActive(true, PageRequest.of(1, 4, Sort.by("registrationDate")));
        assertAll(
                () -> assertEquals(4, users.size()),
                () -> assertEquals("burk", users.get(0).getUsername())
        );

    }
}
