package com.alex.study.hibernatespring.springdatajpatwo;

import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Sort;

import com.alex.study.hibernatespring.springdatajpatwo.model.User;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ModifyQueryTest extends SpringdatajpatwoApplicationTests {

    @Test
    void testModifyLevel() {
        int updated = userRepository.updateLevel(5, 4);
        List<User> users = userRepository.findByLevel(4, Sort.by("username"));

        assertAll(
                () -> assertEquals(1, updated),
                () -> assertEquals(3, users.size()),
                () -> assertEquals("katie", users.get(1).getUsername())
        );
    }

}
