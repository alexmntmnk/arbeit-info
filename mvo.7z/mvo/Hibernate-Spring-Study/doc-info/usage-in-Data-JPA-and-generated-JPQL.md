
Keyword usage in Spring Data JPA and generated JPQL

|Keyword | Example | Generated JPQL |
|---------------|--------------------------------------|-------------------------------------------|
|     Is, Equals      |     findByUsername(String name) <br>findByUsernameIs<br>findByUsernameEquals | . . . where e.username = ?1 | 
| And| findByUsernameAndRegistrationDate<br>(String name, LocalDate date)| . . . where <br>e.username = ?1 and<br>e.registrationdate = ?2  |
| Or| findByUsernameOrRegistrationDate| . . . where <br>e.username = ?1 or<br>e.registrationdate = ?2  |
| LessThan| findByRegistrationDateLessThan| . . . where<br>e.registrationdate < ?1  |
| LessThanEqual| findByRegistrationDateLessThanEqual| . . . where<br>e.registrationdate <= ?1  |
| GreaterThan| findByRegistrationDateGreaterThan| . . . where<br>e.registrationdate > ?1  |
| GreaterThanEqual| findByRegistrationDateGreaterThanEqual| . . . where<br>e.registrationdate >= ?1  |
| Between| findByRegistrationDateBetween| . . . where<br>e.registrationdate<br>between ?1 and ?2  |
| OrderBy| findByRegistrationDateOrderByUsernameDesc| . . where<br>e.registrationdate = ?1<br>order by e.username desc  |
| Like| findByUsernameLike(String name)| . . . where<br>e.username like ?1  |
| NotLike| findByUsernameNotLike| . . . where<br>e.username not like ?1  |
| Before| findByRegistrationDateBefore| . . . where<br>e.registrationdate < ?1  |
| After| findByRegistrationDateAfter(LocalDate date)| . . . where<br>e.registrationdate > ?1  |
| Null, IsNull| findByRegistrationDate(Is)Null| . . . where<br>e.registrationdate<br>is null  |
| NotNull, IsNotNull| findByRegistrationDate(Is)NotNull| . . . where<br>e.registrationdate<br>is not null  |
| Not| findByUsernameNot(String name)| . . . where<br>e.username <> ?1  |
| In| findByRegistrationDateIn<br>(Collection<LocalDate> dates)| registrationDate in (date1,<br>. . . dateN)  |
| NotIn| findByRegistrationDateNotIn<br>(Collection<LocalDate> dates)| registrationDate not in<br>(date1, . . . dateN)  |
| True| findByActiveTrue()| active is true  |
| False| findByActiveFalse()| active is false  |
| StartingWith| findByUsernameStartingWith(String name)| username like name%  |
| EndingWith| findByUsernameEndingWith(String name)| username like %name  |
| Containing| findByUsernameContaining(String name)| username like %name%  |
| IgnoreCase| findByUsernameIgnoreCase(String name)| UPPER(username) = UPPER(name)  |


