package com.alex.study.hibernatespring.onetoonesharedprimarykey.one;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alex.study.hibernatespring.onetoonesharedprimarykey.model.Address;
import com.alex.study.hibernatespring.onetoonesharedprimarykey.model.User;
import com.alex.study.hibernatespring.onetoonesharedprimarykey.repositories.AddressRepository;
import com.alex.study.hibernatespring.onetoonesharedprimarykey.repositories.UserRepository;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@Service
public class TestService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AddressRepository addressRepository;

    // Определите метод хранилища LoadEntities, снабдив его комментарием @Transactional. 
    //Операции, которые нам нужно будет выполнить с базой данных, должны быть транзакционными,
    //и мы позволим Spring управлять этим.
    @Transactional
    public void storeLoadEntities() {

        // Спецификация JPA не включает стандартизированный метод решения проблемы генерации 
        //общего первичного ключа. Это означает, что мы несем ответственность за правильную 
        //настройку значения идентификатора пользовательского экземпляра, прежде чем мы 
        //сохраним его в значении идентификатора связанного экземпляра адреса:
        Address address =
                new Address("Flowers Street", "01246", "Boston");
        addressRepository.save(address);

        User john = new User(address.getId(), // Assign same identifier value
                "John Smith"
        );
        john.setShippingAddress(address);
        userRepository.save(john);

        User user = userRepository.findById(john.getId()).get();
        Address address2 = addressRepository.findById(address.getId()).get();

        assertAll(
                () -> assertEquals("Flowers Street", user.getShippingAddress().getStreet()),
                () -> assertEquals("01246", user.getShippingAddress().getZipcode()),
                () -> assertEquals("Boston", user.getShippingAddress().getCity()),
                () -> assertEquals("Flowers Street", address2.getStreet()),
                () -> assertEquals("01246", address2.getZipcode()),
                () -> assertEquals("Boston", address2.getCity())
        );


        Address addressTwo =
                new Address("Flowers Str", "01245", "Bostonn");
        addressRepository.save(addressTwo);

        // Так не работает, т.к. требуется Id
        User piter = new User();
        piter.setUsername("Piter");
        piter.setShippingAddress(addressTwo);
        // userRepository.save(piter);

    }
}
