package com.alex.study.hibernatespring.onetoonesharedprimarykey;

import org.junit.jupiter.api.Test;

class OnetooneSharedprimarykeyApplicationTests {

	@Test
	void contextLoads() {
	}

}
