package com.alex.study.hibernatespring.onetoonesharedprimarykey.one;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alex.study.hibernatespring.onetoonesharedprimarykey.configuration.SpringDataConfiguration;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SpringDataConfiguration.class})
public class AdvancedMappingSpringDataJPATest {

    @Autowired
    private TestService testService;

    @Test
    void testStoreLoadEntities() {

        // Класс тестирования будет отличаться от ранее представленных, так как он будет делегирован
        //классу TestService. Это позволит нам сохранить транзакционные операции изолированными 
        //в их собственных методах и вызывать эти методы из теста.
        testService.storeLoadEntities();

    }
}
