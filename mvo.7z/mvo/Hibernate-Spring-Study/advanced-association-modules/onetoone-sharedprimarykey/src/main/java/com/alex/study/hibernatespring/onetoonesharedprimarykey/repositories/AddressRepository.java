package com.alex.study.hibernatespring.onetoonesharedprimarykey.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.onetoonesharedprimarykey.model.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {
}
