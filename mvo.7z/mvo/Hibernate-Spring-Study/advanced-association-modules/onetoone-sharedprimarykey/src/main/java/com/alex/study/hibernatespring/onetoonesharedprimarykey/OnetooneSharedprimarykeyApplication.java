package com.alex.study.hibernatespring.onetoonesharedprimarykey;

public class OnetooneSharedprimarykeyApplication {

	public static void main(String[] args) {
	}

}
