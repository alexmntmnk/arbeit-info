package com.alex.study.hibernatespring.onetoonesharedprimarykey.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.onetoonesharedprimarykey.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
