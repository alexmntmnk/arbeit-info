package com.alex.study.hibernatespring.onetoonesharedprimarykey.model;

import javax.persistence.*;

@Entity
@Table(name = "USERS")
public class User {

    // Для пользователя мы не объявляем генератор идентификаторов. Как упоминалось в разделе 5.2.4, 
    // это один из редких случаев, когда мы будем использовать значение идентификатора, 
    //присвоенное приложению.
    @Id
    private Long id;

    private String username;

    @OneToOne(
        // Как обычно, мы должны предпочесть стратегию отложенной загрузки, поэтому мы 
        // переопределяем значение по умолчанию FetchType.EAGER на LAZY.
            fetch = FetchType.LAZY,  // Defaults to EAGER
        // optional=false указывает, что у пользователя должен быть адрес доставки.
            optional = false, // Required for lazy loading with proxies!
        // Схема базы данных, сгенерированная в режиме гибернации, отражает это с помощью 
        // ограничения внешнего ключа. Любое изменение здесь должно быть каскадировано для 
        // решения проблемы. Первичный ключ таблицы USERS также имеет ограничение внешнего ключа, 
        //ссылающееся на первичный ключ таблицы АДРЕСОВ. Смотрите таблицы на рисунке
            cascade = CascadeType.ALL // Any change here must be cascaded to Address
    )
    // Использование @PrimaryKeyJoinColumn делает это однонаправленным сопоставлением общего 
    // первичного ключа "один к одному", от пользователя к адресу.
    @PrimaryKeyJoinColumn
    private Address shippingAddress;

    public User() {
    }

    // Конструкция конструктора слабо обеспечивает это: общедоступный API класса требует
    //значения идентификатора для создания экземпляра.
    public User(Long id, String username) {
        this.id = id;
        this.username = username;
    }

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Address getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(Address shippingAddress) {
        this.shippingAddress = shippingAddress;
    }
}
