package com.alex.study.hibernatespring.mapsmapkey;

import org.junit.jupiter.api.Test;

class MapsMapkeyApplicationTests {

	@Test
	void contextLoads() {
	}

}
