package com.alex.study.hibernatespring.mapsmapkey;

public class MapsMapkeyApplication {

	public static void main(String[] args) {
	}

}
