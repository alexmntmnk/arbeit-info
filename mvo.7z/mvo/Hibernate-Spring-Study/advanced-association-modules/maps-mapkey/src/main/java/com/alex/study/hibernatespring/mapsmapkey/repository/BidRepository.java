package com.alex.study.hibernatespring.mapsmapkey.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.mapsmapkey.model.Bid;

public interface BidRepository extends JpaRepository<Bid, Long> {
}
