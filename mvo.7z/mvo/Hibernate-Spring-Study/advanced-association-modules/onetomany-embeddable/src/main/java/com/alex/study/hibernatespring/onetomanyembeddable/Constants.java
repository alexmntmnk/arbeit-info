package com.alex.study.hibernatespring.onetomanyembeddable;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
