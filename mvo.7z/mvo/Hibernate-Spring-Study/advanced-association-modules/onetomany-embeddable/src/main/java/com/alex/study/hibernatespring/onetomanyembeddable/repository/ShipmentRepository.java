package com.alex.study.hibernatespring.onetomanyembeddable.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.onetomanyembeddable.model.Shipment;

public interface ShipmentRepository extends JpaRepository<Shipment, Long> {
}
