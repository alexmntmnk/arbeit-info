package com.alex.study.hibernatespring.onetomanyembeddable;

public class OnetomanyEmbeddableApplication {

	public static void main(String[] args) {
	}

}
