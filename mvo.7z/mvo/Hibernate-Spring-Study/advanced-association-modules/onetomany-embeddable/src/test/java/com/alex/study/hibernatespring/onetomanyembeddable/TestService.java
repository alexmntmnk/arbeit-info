package com.alex.study.hibernatespring.onetomanyembeddable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alex.study.hibernatespring.onetomanyembeddable.model.Address;
import com.alex.study.hibernatespring.onetomanyembeddable.model.Shipment;
import com.alex.study.hibernatespring.onetomanyembeddable.model.User;
import com.alex.study.hibernatespring.onetomanyembeddable.repository.ShipmentRepository;
import com.alex.study.hibernatespring.onetomanyembeddable.repository.UserRepository;

import static org.junit.jupiter.api.Assertions.*;

@Service
public class TestService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ShipmentRepository shipmentRepository;

    @Transactional
    public void storeLoadEntities() {
        User user = new User("John Smith");
        Address deliveryAddress = new Address("Flowers Street", "01246", "Boston");
        user.setShippingAddress(deliveryAddress);
        userRepository.save(user);

        Shipment firstShipment = new Shipment();
        deliveryAddress.addDelivery(firstShipment);
        shipmentRepository.save(firstShipment);

        Shipment secondShipment = new Shipment();
        deliveryAddress.addDelivery(secondShipment);
        shipmentRepository.save(secondShipment);

        User johnsmith = userRepository.findById(user.getId()).get();

        assertEquals(2, johnsmith.getShippingAddress().getDeliveries().size());
    }
}
