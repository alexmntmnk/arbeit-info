package com.alex.study.hibernatespring.onetomanyembeddable;

import org.junit.jupiter.api.Test;

class OnetomanyEmbeddableApplicationTests {

	@Test
	void contextLoads() {
	}

}
