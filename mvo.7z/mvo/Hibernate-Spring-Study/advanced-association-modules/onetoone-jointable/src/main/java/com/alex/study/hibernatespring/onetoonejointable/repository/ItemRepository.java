package com.alex.study.hibernatespring.onetoonejointable.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.onetoonejointable.model.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {
}
