package com.alex.study.hibernatespring.onetoonejointable;

public class OnetooneJointableApplication {

	public static void main(String[] args) {
	}

}
