package com.alex.study.hibernatespring.onetoonejointable.model;

import org.hibernate.annotations.CreationTimestamp;

import com.alex.study.hibernatespring.onetoonejointable.Constants;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
public class Shipment {

    @Id
    @GeneratedValue(generator = Constants.ID_GENERATOR)
    private Long id;

    @NotNull
    @CreationTimestamp
    private LocalDateTime createdOn;

    @NotNull
    private ShipmentState shipmentState = ShipmentState.TRANSIT;

    // Включена отложенная загрузка с изюминкой: когда Hibernate или Spring Data JPA, использующий
    // Hibernate, загружает отправку, он запрашивает как SHIPMENT,, так и ITEM_SHIPMENT объединения
    // ОТГРУЗОК. Hibernate должен знать, присутствует ли ссылка на элемент, прежде чем он сможет
    // использовать прокси-сервер. Он делает это в одном внешнем SQL-запросе join, так что мы не
    // увидим никаких дополнительных Инструкции SQL. Если в ITEM_SHIPMENT есть строка, 
    // Hibernate использует заполнитель элемента.
    @OneToOne(fetch = FetchType.LAZY)
    // Аннотация @JoinTable является новой; мы всегда должны указывать имя промежуточной таблицы.
    // Это сопоставление эффективно скрывает таблицу соединений; соответствующей таблицы нет 
    // Класс Java. Аннотация определяет имена столбцов таблицы ITEM_SHIPMENT.
    @JoinTable(
            name = "ITEM_SHIPMENT", // Required!
            joinColumns =
            // Столбцом соединения является SHIPMENT_ID (по умолчанию используется значение ID).
            @JoinColumn(name = "SHIPMENT_ID"),  // Defaults to ID
            inverseJoinColumns =
            // Столбец обратного соединения - ITEM_ID (по умолчанию он равен AUCTION_ID).
            @JoinColumn(name = "ITEM_ID",  // Defaults to AUCTION_ID
                    nullable = false,
                    // Спящий режим генерирует УНИКАЛЬНОЕ ограничение для столбца ITEM_ID в схеме. 
                    //Hibernate также генерирует соответствующие ограничения внешнего ключа для столбцов 
                    //таблицы соединений.
                    unique = true)
    )
    private Item auction;

    public Shipment() {
    }

    public Shipment(Item auction) {
        this.auction = auction;
    }

    public Long getId() {
        return id;
    }

    public LocalDateTime getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDateTime createdOn) {
        this.createdOn = createdOn;
    }

    public ShipmentState getShipmentState() {
        return shipmentState;
    }

    public void setShipmentState(ShipmentState shipmentState) {
        this.shipmentState = shipmentState;
    }

    public Item getAuction() {
        return auction;
    }

    public void setAuction(Item auction) {
        this.auction = auction;
    }
}
