package com.alex.study.hibernatespring.onetoonejointable.model;

public enum ShipmentState {

    TRANSIT,
    CONFIRMED

}
