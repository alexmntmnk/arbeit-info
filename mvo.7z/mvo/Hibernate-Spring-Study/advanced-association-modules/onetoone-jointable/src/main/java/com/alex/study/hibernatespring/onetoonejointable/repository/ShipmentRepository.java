package com.alex.study.hibernatespring.onetoonejointable.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.alex.study.hibernatespring.onetoonejointable.model.Shipment;

public interface ShipmentRepository extends JpaRepository<Shipment, Long> {
    @Query("select s from Shipment s inner join fetch s.auction where s.id = :id")
    Shipment findShipmentWithItem(@Param("id") Long id);
}
