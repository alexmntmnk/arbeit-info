package com.alex.study.hibernatespring.onetoonejointable;

import org.junit.jupiter.api.Test;

class OnetooneJointableApplicationTests {

	@Test
	void contextLoads() {
	}

}
