package com.alex.study.hibernatespring.onetomanyemjointable;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
