package com.alex.study.hibernatespring.onetomanyemjointable;

public class OnetomanyEmJointableApplication {

	public static void main(String[] args) {
	}

}
