package com.alex.study.hibernatespring.onetomanyemjointable;

import org.junit.jupiter.api.Test;

class OnetomanyEmJointableApplicationTests {

	@Test
	void contextLoads() {
	}

}
