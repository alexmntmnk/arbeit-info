package com.alex.study.hibernatespring.manytomanybidirectional;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
