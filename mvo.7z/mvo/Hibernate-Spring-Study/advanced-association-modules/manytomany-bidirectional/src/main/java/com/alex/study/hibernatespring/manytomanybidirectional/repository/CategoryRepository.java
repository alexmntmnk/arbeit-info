package com.alex.study.hibernatespring.manytomanybidirectional.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.manytomanybidirectional.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}
