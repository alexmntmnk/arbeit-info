package com.alex.study.hibernatespring.manytomanybidirectional;

public class ManytomanyBidirectionalApplication {

	public static void main(String[] args) {
	}

}
