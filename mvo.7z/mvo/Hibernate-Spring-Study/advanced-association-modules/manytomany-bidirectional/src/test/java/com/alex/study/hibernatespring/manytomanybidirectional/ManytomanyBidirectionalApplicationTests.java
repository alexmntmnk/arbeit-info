package com.alex.study.hibernatespring.manytomanybidirectional;

import org.junit.jupiter.api.Test;

class ManytomanyBidirectionalApplicationTests {

	@Test
	void contextLoads() {
	}

}
