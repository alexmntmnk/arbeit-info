package com.alex.study.hibernatespring.onetomanylist;

import org.junit.jupiter.api.Test;

class OnetomanyListApplicationTests {

	@Test
	void contextLoads() {
	}

}
