package com.alex.study.hibernatespring.onetomanylist.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.alex.study.hibernatespring.onetomanylist.Constants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Entity
public class Item {

    @Id
    @GeneratedValue(generator = Constants.ID_GENERATOR)
    private Long id;

    @NotNull
    private String name;

    @OneToMany
    @JoinColumn(
            name = "ITEM_ID",
            nullable = false
    )
    @OrderColumn(
        // Как уже упоминалось, это однонаправленное отображение: нет другой стороны, “отображаемой по”. 
        //У ставки нет свойства @ManyToOne. Аннотация @OrderColumn установит имя столбца индекса 
        //равным BID_POSITION. В противном случае по умолчанию было бы установлено значение BIDS_ORDER.
            name = "BID_POSITION", // Defaults to BIDS_ORDER
            // Как обычно, мы должны сделать столбец NOT NULL.
            nullable = false
    )
    private List<Bid> bids = new ArrayList<>();

    public Item() {
    }

    public Item(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Bid> getBids() {
        return Collections.unmodifiableList(bids);
    }

    public void addBid(Bid bid) {
        bids.add(bid);
    }

}
