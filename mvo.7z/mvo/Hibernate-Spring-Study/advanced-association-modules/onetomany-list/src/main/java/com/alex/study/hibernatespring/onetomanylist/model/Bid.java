package com.alex.study.hibernatespring.onetomanylist.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.alex.study.hibernatespring.onetomanylist.Constants;

import java.math.BigDecimal;

@Entity
public class Bid {

    @Id
    @GeneratedValue(generator = Constants.ID_GENERATOR)
    private Long id;

    // @ManyToOne
    // @JoinColumn(
            // name = "ITEM_ID",
        // После того как мы добавили  ManyToOne и JoinColumn
        //Коллекция Item#bids больше не доступна только для чтения, поскольку Hibernate теперь 
        //должен сохранять индекс каждого элемента. Если сторона, предлагающая цену#товар, была 
        //владельцем отношения, Спящий режим игнорировал бы коллекцию при хранении данных 
        // и не записывал бы индексы элементов. Мы должны дважды сопоставить @JoinColumn, 
        //а затем отключить запись на стороне @ManyToOne с помощью updatable=false и insertable=false. 
        //Hibernate теперь учитывает сторону сбора при хранении данных, включая индекс каждого
        // элемента. @ManyToOne фактически доступен только для чтения, как это было бы, если бы 
        //у него был атрибут mappedBy.
            // updatable = false, insertable = false // Disable writing!
    // )
    @NotNull // For schema generation
    private Item item;

    @NotNull
    private BigDecimal amount;

    public Bid() {
    }

    public Bid(BigDecimal amount, Item item) {
        this.amount = amount;
        this.item = item;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
