package com.alex.study.hibernatespring.onetomanylist;

public class OnetomanyListApplication {

	public static void main(String[] args) {
	}

}
