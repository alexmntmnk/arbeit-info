package com.alex.study.hibernatespring.onetomanylist;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
