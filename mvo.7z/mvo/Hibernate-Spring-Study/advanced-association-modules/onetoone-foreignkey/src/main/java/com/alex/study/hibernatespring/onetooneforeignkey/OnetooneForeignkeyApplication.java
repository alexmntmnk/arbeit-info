package com.alex.study.hibernatespring.onetooneforeignkey;

public class OnetooneForeignkeyApplication {

	public static void main(String[] args) {
	}

}
