package com.alex.study.hibernatespring.onetooneforeignkey;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
