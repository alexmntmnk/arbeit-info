package com.alex.study.hibernatespring.onetooneforeignkey.model;

import javax.persistence.*;

import com.alex.study.hibernatespring.onetooneforeignkey.Constants;

@Entity
@Table(name = "USERS")
public class User {

    @Id
    @GeneratedValue(generator = Constants.ID_GENERATOR)
    private Long id;

    private String username;

    @OneToOne(
            fetch = FetchType.LAZY,
            // Нам не нужны какие-либо специальные генераторы идентификаторов или назначения первичного 
            //ключа; мы убедимся, что адрес доставки не равен нулю.
            optional = false, // NOT NULL
            cascade = CascadeType.PERSIST
    )
    // Вместо @PrimaryKeyJoinColumn мы применяем обычный @JoinColumn, который по умолчанию 
    //будет иметь значение SHIPPINGADDRESS_ID. Если вы больше знакомы с SQL, чем с JPA, 
    // это помогает думать о “столбце внешнего ключа” каждый раз, когда вы видите @JoinColumn 
    //в сопоставлении.
    @JoinColumn(unique = true) // Defaults to SHIPPINGADDRESS_ID
    private Address shippingAddress;

    public User() {
    }

    public User(String username) {
        this.username = username;
    }

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Address getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(Address shippingAddress) {
        this.shippingAddress = shippingAddress;
    }
}
