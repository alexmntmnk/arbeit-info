package com.alex.study.hibernatespring.onetooneforeignkey;

import org.junit.jupiter.api.Test;

class OnetooneForeignkeyApplicationTests {

	@Test
	void contextLoads() {
	}

}
