package com.alex.study.hibernatespring.onetomanyjointable;

import org.junit.jupiter.api.Test;

class OnetomanyJointableApplicationTests {

	@Test
	void contextLoads() {
	}

}
