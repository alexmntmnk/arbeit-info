package com.alex.study.hibernatespring.onetomanyjointable.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.onetomanyjointable.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
