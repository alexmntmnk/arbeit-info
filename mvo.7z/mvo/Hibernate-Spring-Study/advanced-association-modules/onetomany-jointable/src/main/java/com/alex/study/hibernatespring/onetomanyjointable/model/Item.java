package com.alex.study.hibernatespring.onetomanyjointable.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.alex.study.hibernatespring.onetomanyjointable.Constants;

@Entity
public class Item {

    @Id
    @GeneratedValue(generator = Constants.ID_GENERATOR)
    private Long id;

    @NotNull
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinTable(
            name = "ITEM_BUYER",
            joinColumns =
            // Если товар не был куплен, в ITEM_BUYER нет соответствующей строки присоединяйтесь
            // к таблице. Таким образом, связь будет необязательной. Столбец соединения называется
            //ITEM_ID (по умолчанию используется значение ID).
            @JoinColumn(name = "ITEM_ID"), // Defaults to ID
            inverseJoinColumns =
            // Столбец обратного соединения по умолчанию будет иметь значение BUYER_ID, и оно не 
            //может быть обнулено.
            @JoinColumn(nullable = false) // Defaults to BUYER_ID
    )
    private User buyer;

    public Item() {
    }

    public Item(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public User getBuyer() {
        return buyer;
    }

    public void setBuyer(User buyer) {
        this.buyer = buyer;
    }

    // ...
}
