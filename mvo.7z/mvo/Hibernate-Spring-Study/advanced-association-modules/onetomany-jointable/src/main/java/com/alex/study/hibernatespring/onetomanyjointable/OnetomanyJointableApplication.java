package com.alex.study.hibernatespring.onetomanyjointable;

public class OnetomanyJointableApplication {

	public static void main(String[] args) {
	}

}
