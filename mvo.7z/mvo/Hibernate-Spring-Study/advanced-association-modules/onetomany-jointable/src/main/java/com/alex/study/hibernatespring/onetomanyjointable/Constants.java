package com.alex.study.hibernatespring.onetomanyjointable;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
