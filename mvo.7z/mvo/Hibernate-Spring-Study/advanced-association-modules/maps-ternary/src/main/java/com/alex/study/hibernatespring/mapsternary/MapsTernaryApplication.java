package com.alex.study.hibernatespring.mapsternary;

public class MapsTernaryApplication {

	public static void main(String[] args) {
	}

}
