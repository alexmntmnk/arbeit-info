package com.alex.study.hibernatespring.mapsternary;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
