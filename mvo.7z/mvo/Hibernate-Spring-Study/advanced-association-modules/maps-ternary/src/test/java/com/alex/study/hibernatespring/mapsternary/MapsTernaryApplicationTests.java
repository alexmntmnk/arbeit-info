package com.alex.study.hibernatespring.mapsternary;

import org.junit.jupiter.api.Test;

class MapsTernaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
