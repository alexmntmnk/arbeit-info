package com.alex.study.hibernatespring.onetomanybag;

import org.junit.jupiter.api.Test;

class OnetomanyBagApplicationTests {

	@Test
	void contextLoads() {
	}

}
