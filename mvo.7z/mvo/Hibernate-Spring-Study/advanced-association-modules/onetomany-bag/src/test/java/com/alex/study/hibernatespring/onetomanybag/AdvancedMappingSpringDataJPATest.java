package com.alex.study.hibernatespring.onetomanybag;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alex.study.hibernatespring.onetomanybag.configuration.SpringDataConfiguration;
import com.alex.study.hibernatespring.onetomanybag.model.Bid;
import com.alex.study.hibernatespring.onetomanybag.model.Item;
import com.alex.study.hibernatespring.onetomanybag.repositories.BidRepository;
import com.alex.study.hibernatespring.onetomanybag.repositories.ItemRepository;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SpringDataConfiguration.class})
public class AdvancedMappingSpringDataJPATest {

    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private BidRepository bidRepository;

    @Test
    void testStoreLoadEntities() {

        Item item = new Item("Foo");
        itemRepository.save(item);

        Bid someBid = new Bid(new BigDecimal("123.00"), item);
        item.addBid(someBid);
        item.addBid(someBid);
        bidRepository.save(someBid);

        Item item2 = itemRepository.findItemWithBids(item.getId());

        assertAll(
                () -> assertEquals(2, item.getBids().size()),
                () -> assertEquals(1, item2.getBids().size())
        );

        Bid bid = new Bid(new BigDecimal("456.00"), item);
        // Этот пример кода запускает один SQL SELECT для загрузки элемента. Спящий режим по-прежнему 
        // инициализирует и возвращает прокси-сервер Item с SELECT, как только мы вызываем 
        // item.addBid(). Но до тех пор, пока мы не выполним итерацию коллекции, больше никаких
        //  запросов не потребуется, и ВСТАВКА для новой ставки будет выполнена без загрузки всех 
        // ставок. Если коллекция представляет собой набор или список, Hibernate загружает все
        // элементы, когда мы добавляем другой элемент.
        item.addBid(bid); // No SELECT!
        bidRepository.save(bid);

        Item item3 = itemRepository.findItemWithBids(item.getId());

        assertEquals(2, item3.getBids().size());

    }
}
