package com.alex.study.hibernatespring.onetomanybag;

public class OnetomanyBagApplication {

	public static void main(String[] args) {
	}

}
