package com.alex.study.hibernatespring.onetomanybag.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.onetomanybag.model.Bid;

public interface BidRepository extends JpaRepository<Bid, Long> {
}
