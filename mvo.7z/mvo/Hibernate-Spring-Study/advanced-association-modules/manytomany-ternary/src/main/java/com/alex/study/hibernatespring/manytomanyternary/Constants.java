package com.alex.study.hibernatespring.manytomanyternary;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
