package com.alex.study.hibernatespring.manytomanyternary.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.alex.study.hibernatespring.manytomanyternary.model.Category;
import com.alex.study.hibernatespring.manytomanyternary.model.Item;

import java.util.List;

public interface CategoryRepository extends JpaRepository<Category, Long> {

    @Query("select c from Category c join c.categorizedItems ci where ci.item = :itemParameter")
    List<Category> findCategoryWithCategorizedItems(@Param("itemParameter") Item itemParameter);
}
