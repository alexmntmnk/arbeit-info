package com.alex.study.hibernatespring.manytomanyternary.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.manytomanyternary.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
