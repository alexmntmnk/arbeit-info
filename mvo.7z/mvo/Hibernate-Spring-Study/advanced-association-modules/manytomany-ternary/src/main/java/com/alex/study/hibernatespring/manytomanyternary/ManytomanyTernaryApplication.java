package com.alex.study.hibernatespring.manytomanyternary;

public class ManytomanyTernaryApplication {

	public static void main(String[] args) {
	}

}
