package com.alex.study.hibernatespring.manytomanyternary.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.manytomanyternary.model.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {
}
