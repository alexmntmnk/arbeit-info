package com.alex.study.hibernatespring.manytomanyternary;

import org.junit.jupiter.api.Test;

class ManytomanyTernaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
