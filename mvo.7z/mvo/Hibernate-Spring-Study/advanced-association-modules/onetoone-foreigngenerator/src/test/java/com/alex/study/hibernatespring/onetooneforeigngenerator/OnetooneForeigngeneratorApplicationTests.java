package com.alex.study.hibernatespring.onetooneforeigngenerator;

import org.junit.jupiter.api.Test;
class OnetooneForeigngeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
