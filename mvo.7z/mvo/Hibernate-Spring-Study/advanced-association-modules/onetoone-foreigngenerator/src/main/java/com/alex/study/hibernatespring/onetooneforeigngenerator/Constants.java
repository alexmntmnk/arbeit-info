package com.alex.study.hibernatespring.onetooneforeigngenerator;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
