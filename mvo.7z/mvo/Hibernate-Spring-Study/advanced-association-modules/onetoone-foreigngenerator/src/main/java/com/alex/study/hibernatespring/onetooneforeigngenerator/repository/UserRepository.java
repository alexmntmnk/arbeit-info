package com.alex.study.hibernatespring.onetooneforeigngenerator.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.onetooneforeigngenerator.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
