package com.alex.study.hibernatespring.onetooneforeigngenerator.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.onetooneforeigngenerator.model.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {
}
