package com.alex.study.hibernatespring.onetooneforeigngenerator;

public class OnetooneForeigngeneratorApplication {

	public static void main(String[] args) {
	}

}
