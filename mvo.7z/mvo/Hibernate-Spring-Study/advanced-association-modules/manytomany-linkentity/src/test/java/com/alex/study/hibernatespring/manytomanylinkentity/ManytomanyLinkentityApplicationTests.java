package com.alex.study.hibernatespring.manytomanylinkentity;

import org.junit.jupiter.api.Test;

class ManytomanyLinkentityApplicationTests {

	@Test
	void contextLoads() {
	}

}
