package com.alex.study.hibernatespring.manytomanylinkentity.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Table(name = "CATEGORY_ITEM")
//Класс является неизменяемым, как указано в аннотациях @org.hibernate.annotations.Immutable
@org.hibernate.annotations.Immutable
public class CategorizedItem {

    @Embeddable
    //Классу сущностей требуется свойство identifier. Первичный ключ таблицы ссылок представляет
    // собой комбинацию CATEGORY_ID и ITEM_ID. Конечно, мы можем перенести этот класс Id в 
    //его собственный файл.
    public static class Id implements Serializable {

        @Column(name = "CATEGORY_ID")
        private Long categoryId;

        @Column(name = "ITEM_ID")
        private Long itemId;

        public Id() {
        }

        public Id(Long categoryId, Long itemId) {
            this.categoryId = categoryId;
            this.itemId = itemId;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Id id = (Id) o;
            return Objects.equals(categoryId, id.categoryId) &&
                    Objects.equals(itemId, id.itemId);
        }

        @Override
        public int hashCode() {
            return Objects.hash(categoryId, itemId);
        }
    }

    // Новая аннотация @EmbeddedId сопоставляет свойство identifier и его составные ключевые
    // столбцы с таблицей сущности.
    @EmbeddedId
    private Id id = new Id();

    // Основное свойство, сопоставляющее добавленное по имени пользователя со столбцом таблицы соединений.
    @Column(updatable = false)
    @NotNull
    private String addedBy;

    // Основное свойство, сопоставляющее добавленную временную метку On со столбцом таблицы 
    //объединения. Это “дополнительная информация о ссылке”, которая нас интересует.
    @Column(updatable = false)
    @NotNull
    @CreationTimestamp
    private LocalDateTime addedOn;

    // Категория свойств @ManyToOne уже отображена в идентификаторе.
    @ManyToOne
    @JoinColumn(
            name = "CATEGORY_ID",
            insertable = false, updatable = false)
    private Category category;

    // Элемент свойства @ManyToOne уже отображен в идентификаторе. Хитрость здесь в том, чтобы 
    //сделать их доступными только для чтения с настройками updatable=false, insertable=false. 
    //Это означает, что Hibernate или Spring Data JPA, использующие Hibernate, записывают значения 
    //этих столбцов, принимая значение идентификатора категоризированного элемента. В то же время
    // мы можем читать и просматривать связанные экземпляры с помощью categorizedItem.GetItem() 
    //и getCategory(). (Если мы дважды сопоставим один и тот же столбец, не делая одно 
    //сопоставление доступным только для чтения, Hibernate или Spring Data JPA, использующие 
    //Hibernate, будут жалуйтесь при запуске на дублирующееся сопоставление столбцов.)
    @ManyToOne
    @JoinColumn(
            name = "ITEM_ID",
            insertable = false, updatable = false)
    private Item item;

    public CategorizedItem() {
    }

    // Мы также можем видеть, что создание категоризированного элемента включает в себя установку 
    //значений идентификатора. Приложение всегда присваивает значения составного ключа; 
    //Hibernate их не генерирует.
    public CategorizedItem(String addedByUsername,
                           Category category,
                           Item item) {

        // Конструктор устанавливает значение поля added By и гарантирует ссылочную целостность,
        // управляя коллекциями с обеих сторон ассоциации.
        this.addedBy = addedByUsername;
        this.category = category;
        this.item = item;

        // Конструктор устанавливает значение поля CategoryID. Далее мы сопоставим эти коллекции,
        // чтобы включить двунаправленную навигацию. Это однонаправленное отображение, и его 
        //достаточно для поддержки отношения "многие ко многим" между категорией и товаром. 
        // Чтобы создать ссылку, мы создаем экземпляр и сохраняем классифицированный элемент. 
        //Если мы хотим разорвать ссылку, мы удаляем элемент CategorizedItem. Конструктор 
        //CategorizedItem требует, чтобы мы предоставляли уже постоянные экземпляры категории и элемента.
        this.id.categoryId = category.getId();
        this.id.itemId = item.getId();

        // Guarantee referential integrity if made bidirectional
        category.addCategorizedItem(this);
        item.addCategorizedItem(this);
    }

    public Id getId() {
        return id;
    }

    public String getAddedBy() {
        return addedBy;
    }

    public LocalDateTime getAddedOn() {
        return addedOn;
    }

    public Category getCategory() {
        return category;
    }

    public Item getItem() {
        return item;
    }
}
