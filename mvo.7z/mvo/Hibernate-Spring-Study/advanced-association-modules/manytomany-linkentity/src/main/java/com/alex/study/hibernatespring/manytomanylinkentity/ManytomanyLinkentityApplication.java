package com.alex.study.hibernatespring.manytomanylinkentity;

public class ManytomanyLinkentityApplication {

	public static void main(String[] args) {
	}

}
