package com.alex.study.hibernatespring.manytomanylinkentity.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.manytomanylinkentity.model.CategorizedItem;

public interface CategorizedItemRepository extends JpaRepository<CategorizedItem, CategorizedItem.Id> {
}
