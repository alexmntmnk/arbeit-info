package com.alex.study.hibernatespring.manytomanylinkentity;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
