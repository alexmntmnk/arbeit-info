package com.alex.study.hibernatespring.manytomanylinkentity.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.manytomanylinkentity.model.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {
}
