package com.alex.study.hibernatespring.parentjpa;

public class ParentJpaApplication {

	public static void main(String[] args) {
	}

}
