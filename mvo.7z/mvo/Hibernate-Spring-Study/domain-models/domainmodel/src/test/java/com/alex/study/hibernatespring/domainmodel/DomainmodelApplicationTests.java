package com.alex.study.hibernatespring.domainmodel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DomainmodelApplicationTests {

	@Test
	void contextLoads() {
	}

}
