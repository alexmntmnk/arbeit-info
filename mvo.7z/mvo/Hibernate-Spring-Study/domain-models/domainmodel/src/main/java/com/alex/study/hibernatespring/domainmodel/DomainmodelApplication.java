package com.alex.study.hibernatespring.domainmodel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DomainmodelApplication {

	public static void main(String[] args) {
		SpringApplication.run(DomainmodelApplication.class, args);
	}

}
