
package com.alex.study.hibernatespring.domainmodel.ex03;

public class Bid {

    private Item item;

    public Item getItem() {
        return item;
    }

    void setItem(Item item) {
        this.item = item;
    }

}
