package com.alex.study.hibernatespring.parentboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParentBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParentBootApplication.class, args);
	}

}
