package com.alex.study.hibernatespring.parentboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParentBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
