# parent-boot
This is a parent module for all projects using Spring Boot

Это родительский модуль для всех проектов, использующих Spring Boot

