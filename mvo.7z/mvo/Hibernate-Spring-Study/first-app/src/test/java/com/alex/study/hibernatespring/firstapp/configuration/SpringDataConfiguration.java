package com.alex.study.hibernatespring.firstapp.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Properties;

// Эта Аннотация позволяет сканировать пакет, полученный в качестве аргумента для репозиториев  данных Spring.
@EnableJpaRepositories("com.alex.study.hibernatespring.firstapp.repositories")
public class SpringDataConfiguration {
    @Bean
    public DataSource dataSource() {
        // Создаем компонент источника данных.
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        // Задаем свойства JDBC—драйвера
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://10.151.68.8:3306/CH02?serverTimezone=UTC");
        dataSource.setUsername("root");
        dataSource.setPassword("rtms");
        return dataSource;
    }

    // Создадим компонент transaction manager на основе фабрики entity manager. Каждое взаимодействие с 
    //  базой данных должно происходить в пределах границ транзакции, а Spring Data нуждается в 
    // компоненте transaction manager.
    @Bean
    public JpaTransactionManager transactionManager(EntityManagerFactory emf) {
        return new JpaTransactionManager(emf);
    }

    // Создадим компонент JpaVendorAdapter, необходимый JPA для взаимодействия с Hibernate.
    @Bean
    public JpaVendorAdapter jpaVendorAdapter() {
        HibernateJpaVendorAdapter jpaVendorAdapter = new HibernateJpaVendorAdapter();
        // Настроим этот адаптер поставщика для доступа к базе данных MySQL
        jpaVendorAdapter.setDatabase(Database.MYSQL);
        // Показывать SQL-код во время его выполнения
        jpaVendorAdapter.setShowSql(true);
        return jpaVendorAdapter;
    }

    // Создадим LocalContainerEntityManagerFactoryBean. Это фабричный компонент, который создает
    // EntityManagerFactory в соответствии со стандартным контрактом начальной загрузки контейнера JPA
    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean =
                new LocalContainerEntityManagerFactoryBean();
        // Установите источник данных
        localContainerEntityManagerFactoryBean.setDataSource(dataSource());
        Properties properties = new Properties();
        // Установите так, чтобы база данных создавалась с нуля при каждом запуске программы
        properties.put("hibernate.hbm2ddl.auto", "create");
        localContainerEntityManagerFactoryBean.setJpaProperties(properties);
        // Установите адаптер поставщика
        localContainerEntityManagerFactoryBean.setJpaVendorAdapter(jpaVendorAdapter());
        // Настройте пакеты на проверку на наличие классов сущностей. Поскольку объект сообщения находится в
        //com.alex.study.hibernatespring.firstapp, мы настроили проверку этого пакета.
        localContainerEntityManagerFactoryBean
            .setPackagesToScan("com.alex.study.hibernatespring.firstapp");
        return localContainerEntityManagerFactoryBean;
        
    }
}
