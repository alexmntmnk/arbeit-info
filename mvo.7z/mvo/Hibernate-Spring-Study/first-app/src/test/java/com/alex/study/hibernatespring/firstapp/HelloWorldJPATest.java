package com.alex.study.hibernatespring.firstapp;

import org.junit.jupiter.api.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class HelloWorldJPATest {

    @Test
    public void storeLoadMessage() {

        // нам нужен EntityManagerFactory для взаимодействия с базой данных
        EntityManagerFactory emf =
                Persistence.createEntityManagerFactory("ch02");

        try {
            // Начнинаем новый сеанс работы с базой данных, создав EntityManager. Это будет контекст для всех операций сохранения.
            EntityManager em = emf.createEntityManager();
            // начнинаем транзакцию в этом потоке выполнения.
            em.getTransaction().begin();

            // Создаем новый экземпляр класса сопоставленной модели домена
            Message message = new Message();
            message.setText("Hello World!");

            // Подключаем временный экземпляр к контексту сохранения; мы делаем его постоянным.
            // Теперь Hibernate знает, что мы хотим сохранить эти данные, но это еще не сохранение
            em.persist(message);

            // фиксируем транзакцию. Hibernate автоматически проверяет контекст сохранения и выполняет необходимую
            // инструкцию SQL INSERT, которая приведена ниже
            em.getTransaction().commit();
            //INSERT into MESSAGE (ID, TEXT) values (1, 'Hello World!')

            // Создаем новую транзакцию
            // Каждое взаимодействие с базой данных должно происходить в пределах границ транзакции,
            // даже если мы только считываем данные, поэтому мы начинаем новую транзакцию. Любой потенциальный сбой
            //возникающий с этого момента, не повлияет на ранее зафиксированную транзакцию.
            em.getTransaction().begin();

            // Выполним запрос для извлечения всех экземпляров сообщения из базы данных.
            List<Message> messages =
                    em.createQuery("select m from Message m", Message.class).getResultList();
            //SELECT * from MESSAGE

            // Мы можем изменить значение свойства. Hibernate обнаруживает это автоматически поскольку 
            // загруженное сообщение все еще привязано к контексту сохранения, в котором оно было загружено.
            messages.get(messages.size() - 1).setText("Hello World from JPA!");

            // При фиксации Hibernate проверяет контекст сохранения на наличие измененного состояния и автоматически 
            // выполняет обновление SQL для синхронизации объектов в памяти с состоянием базы данных.
            em.getTransaction().commit();
            //UPDATE MESSAGE set TEXT = 'Hello World from JPA!' where ID = 1

            assertAll(
                    () -> assertEquals(1, messages.size()),
                    () -> assertEquals("Hello World from JPA!", messages.get(0).getText())
            );

            // Закрываем EntityManager
            em.close();

        } finally {
            // Закрываем EntityManagerFactory
            emf.close();
        }
    }

}
