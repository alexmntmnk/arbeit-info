package com.alex.study.hibernatespring.firstapp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alex.study.hibernatespring.firstapp.configuration.SpringDataConfiguration;
import com.alex.study.hibernatespring.firstapp.repositories.MessageRepository;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

// Это расширение используется для интеграции контекста Spring test с тестом JUnit 5 Jupiter.
@ExtendWith(SpringExtension.class)
// Контекст тестирования Spring настраивается с использованием компонентов, определенных в ранее 
// представленном классе SpringDataConfiguration.
@ContextConfiguration(classes = {SpringDataConfiguration.class})
public class HelloWorldSpringDataJPATest {

    // Компонент MessageRepository автоматически подключается Spring. Это возможно
    //Если мы вызовем messageRepository.getClass(), мы получим что—то вроде прокси объекта com.sun.proxy.$Proxy41
    // Autowired не рекомендуется к использованию, лучше это делать через консторуктор
    @Autowired
    private MessageRepository messageRepository;

    @Test
    public void storeLoadMessage() {
        Message message = new Message();
        message.setText("Hello World from Spring Data JPA!");

        // Метод save наследуется от интерфейса CrudRepository, и его тело будет сгенерировано Spring Data JPA
        // при создании прокси-класса. Это просто сохранит объект сообщения в базе данных.
        messageRepository.save(message);

        // Извлеките сообщения из хранилища. Метод findAll унаследован от интерфейс 
        //CrudRepository и его тело будут сгенерированы Spring Data JPA
        List<Message> messages = (List<Message>) messageRepository.findAll();

        assertAll(
                () -> assertEquals(1, messages.size()),
                () -> assertEquals("Hello World from Spring Data JPA!", messages.get(0).getText())
        );

    }
}
