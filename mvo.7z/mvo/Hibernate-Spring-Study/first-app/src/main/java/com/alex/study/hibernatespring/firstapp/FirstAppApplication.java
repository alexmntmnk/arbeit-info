package com.alex.study.hibernatespring.firstapp;


public class FirstAppApplication {

	public static void main(String[] args) {
	}

}
