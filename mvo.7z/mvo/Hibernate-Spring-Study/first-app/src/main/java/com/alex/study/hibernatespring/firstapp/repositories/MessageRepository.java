package com.alex.study.hibernatespring.firstapp.repositories;

import org.springframework.data.repository.CrudRepository;

import com.alex.study.hibernatespring.firstapp.Message;

public interface MessageRepository extends CrudRepository<Message, Long> {

}
