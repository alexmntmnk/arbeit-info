package com.alex.study.hibernatespring.transactiondata.trdata;

import org.junit.jupiter.api.Test;

class TrDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
