package com.alex.study.hibernatespring.transactiondata.trdata;

public class TrDataApplication {

	public static void main(String[] args) {
	}

}
