package com.alex.study.hibernatespring.transactiondata.trdata.model;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
