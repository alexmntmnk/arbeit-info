package com.alex.study.hibernatespring.transactiondata.tradata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
