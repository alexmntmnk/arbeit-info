package com.alex.study.hibernatespring.transactiondata.tradata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TraDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraDataApplication.class, args);
	}

}
