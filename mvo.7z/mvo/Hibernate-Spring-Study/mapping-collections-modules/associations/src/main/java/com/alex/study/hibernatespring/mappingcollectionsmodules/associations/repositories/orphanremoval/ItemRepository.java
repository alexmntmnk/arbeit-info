package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.orphanremoval;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.orphanremoval.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {
    // Новый метод findItemWithBids с помощью ставок получит товар по идентификатору, включая 
    //коллекцию ставок.
    //Чтобы извлечь эту коллекцию, мы будем использовать функцию внутренней выборки соединения JPQL.
    @Query("select i from Item i inner join fetch i.bids where i.id = :id")
    Item findItemWithBids(@Param("id") Long id);
}
