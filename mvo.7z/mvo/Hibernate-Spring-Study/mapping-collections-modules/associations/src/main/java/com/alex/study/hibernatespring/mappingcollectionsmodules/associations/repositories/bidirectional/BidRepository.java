package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.bidirectional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.bidirectional.Bid;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.bidirectional.Item;

import java.util.List;
import java.util.Set;

public interface BidRepository extends JpaRepository<Bid, Long> {
    List<Bid> findByItem(Item item);
}
