package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.cascadepersist;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.cascadepersist.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {

}
