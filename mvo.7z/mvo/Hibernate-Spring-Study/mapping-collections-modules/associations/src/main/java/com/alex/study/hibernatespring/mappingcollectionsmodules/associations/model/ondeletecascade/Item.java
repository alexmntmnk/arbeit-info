package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.ondeletecascade;

import javax.persistence.*;

import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.Constants;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Item {

    @Id
    @GeneratedValue(generator = Constants.ID_GENERATOR)
    private Long id;

    private String name;

    // Одна из особенностей Hibernate видна здесь: аннотация @OnDelete влияет только на генерацию 
    // схемы Hibernate. Настройки, влияющие на генерацию схемы, обычно находятся на стороне 
    //“other” mappedBy, где сопоставляется столбец внешнего ключа/соединения. Аннотация 
    // @OnDelete обычно находится рядом с @ManyToOne в Bid. Однако, когда ассоциация 
    // отображается двунаправленно, Hibernate распознает ее только на стороне @OneToMany.
    @OneToMany(mappedBy = "item", cascade = CascadeType.PERSIST)
    // Hibernate quirk: Schema options usually on the 'mappedBy' side
    @org.hibernate.annotations.OnDelete(
            action = org.hibernate.annotations.OnDeleteAction.CASCADE
    )
    private Set<Bid> bids = new HashSet<>();

    public Item() {
    }

    public Item(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Bid> getBids() {
        return Collections.unmodifiableSet(bids);
    }

    public void addBid(Bid bid) {
        bids.add(bid);
    }

    public void removeBid(Bid bid) {
        bids.remove(bid);
    }
}
