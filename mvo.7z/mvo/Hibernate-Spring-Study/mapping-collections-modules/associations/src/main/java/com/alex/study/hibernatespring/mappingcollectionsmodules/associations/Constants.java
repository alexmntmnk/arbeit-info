package com.alex.study.hibernatespring.mappingcollectionsmodules.associations;

public class Constants {
    public static final String ID_GENERATOR = "ID_GENERATOR";
}
