package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.cascadepersist;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.cascadepersist.Item;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.cascadepersist.Bid;

import java.util.Set;

public interface BidRepository extends JpaRepository<Bid, Long> {
    Set<Bid> findByItem(Item item);
}
