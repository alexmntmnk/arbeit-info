package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.cascaderemove;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.cascaderemove.Bid;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.cascaderemove.Item;

import java.util.Set;

public interface BidRepository extends JpaRepository<Bid, Long> {
    Set<Bid> findByItem(Item item);
}
