package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.bidirectional;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.Constants;

import java.math.BigDecimal;

@Entity
public class Bid {

    @Id
    @GeneratedValue(generator = Constants.ID_GENERATOR)
    private Long id;

    // Аннотация @ManyToOne помечает свойство как ассоциацию сущностей, и это обязательно. 
    //Его параметр выборки по умолчанию имеет значение EAGER, что означает, что связанный
    // элемент загружается всякий раз, когда загружается ставка. Обычно мы предпочитаем
    // отложенную загрузку в качестве стратегии по умолчанию, и подробнее об этом мы
    // поговорим позже в теме 12
    @ManyToOne(fetch = FetchType.LAZY) // Defaults to EAGER
    @JoinColumn(name = "ITEM_ID", nullable = false)
    private Item item;

    @NotNull
    private BigDecimal amount;

    public Bid() {
    }

    public Bid(BigDecimal amount, Item item) {
        this.amount = amount;
        this.item = item;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
