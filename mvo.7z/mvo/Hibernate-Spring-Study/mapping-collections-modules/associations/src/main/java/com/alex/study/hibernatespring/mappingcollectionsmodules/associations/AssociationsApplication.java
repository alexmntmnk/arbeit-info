package com.alex.study.hibernatespring.mappingcollectionsmodules.associations;

public class AssociationsApplication {

	public static void main(String[] args) {
	}

}
