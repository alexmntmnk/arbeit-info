package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.bidirectionaltwo;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.configuration.SpringDataConfiguration;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.bidirectionaltwo.Bid;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.bidirectionaltwo.Item;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.bidirectionaltwo.BidRepository;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.bidirectionaltwo.ItemRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SpringDataConfiguration.class})
public class MappingAssociationsSpringDataJPATest {

    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private BidRepository bidRepository;

    @Test
    void storeLoadEntities() {

        Item item = new Item("Foo");
        Bid bid = new Bid(BigDecimal.valueOf(100), item);
        Bid bid2 = new Bid(BigDecimal.valueOf(200), item);
        Bid bid3 = new Bid(BigDecimal.valueOf(300), item);

        itemRepository.save(item);
        item.addBid(bid);
        item.addBid(bid2);
        item.addBid(bid3);
        bidRepository.save(bid);
        bidRepository.save(bid2);
        bidRepository.save(bid3);

        List<Item> items = itemRepository.findAll();
        Set<Bid> bids = bidRepository.findByItem(item);

        assertAll(
                () -> assertEquals(1, items.size()),
                () -> assertEquals(3, bids.size())
        );      
    }

    @Test
    void storeEntities() {

        // В этом тесте мы получаем LazyInitializationException
        // Эта ошибка связана с тем что ленивая загрузка работает только на уровне JPA, а дальше 
        // транзакция закрывается и эта сущность уже будет не доступна
        // Решить эту проблему можно рахными способами
        // - FetchType.EAGER но это анти-патерн, т.к. это будет грузить все и сразу
        // - используйте @Transactional в контроллере . Его не следует использовать 
        // - используйте OpenSessionInViewFilter , сообщается о многих недостатках, возможная нестабильность
        // - Выполняйте всю эту логику на сервисном уровне (с @Transactional), это самый лучший вариант


        Item item = new Item("Foos");
        Bid bid = new Bid(BigDecimal.valueOf(100), item);
        Bid bid2 = new Bid(BigDecimal.valueOf(200), item);
        Bid bid3 = new Bid(BigDecimal.valueOf(300), item);
        Bid bid4 = new Bid(BigDecimal.valueOf(400), item);

        itemRepository.save(item);
        item.addBid(bid);
        item.addBid(bid2);
        item.addBid(bid3);
        item.addBid(bid4);
        bidRepository.save(bid);
        bidRepository.save(bid2);
        bidRepository.save(bid3);
        bidRepository.save(bid4);

        List<Item> items = itemRepository.findAll();
        // Получим список ставок из товара, не обращаясь к БД самим - LazyInitializationException
        // Set<Bid> bids = items.get(1).getBids();
        
        assertAll(
                () -> assertEquals(2, items.size())
                // () -> assertEquals(4, bids.size())
        );      
    }    

    @Test
    void storeLoadCascadeEntities() {
        // В данной конфигруации каскадная запись в таблицу ставок не работает, требутся доп настройки,
        // они будут рассмотрены далее

        Item item = new Item("Fooss");
        Bid bid = new Bid(BigDecimal.valueOf(100), item);
        Bid bid2 = new Bid(BigDecimal.valueOf(200), item);
        Bid bid3 = new Bid(BigDecimal.valueOf(300), item);


        item.addBid(bid);
        item.addBid(bid2);
        item.addBid(bid3);
        itemRepository.save(item);        
        // bidRepository.save(bid);
        // bidRepository.save(bid2);
        // bidRepository.save(bid3);

        List<Item> items = itemRepository.findAll();
        // Set<Bid> bids = bidRepository.findByItem(item);

        assertAll(
                () -> assertEquals(3, items.size())
                // () -> assertEquals(3, bids.size())
        );      
    }


}
