package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.bidirectional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.configuration.SpringDataConfiguration;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.bidirectional.Bid;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.bidirectional.Item;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.bidirectional.BidRepository;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.bidirectional.ItemRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SpringDataConfiguration.class})
public class MappingAssociationsSpringDataJPATest {

    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private BidRepository bidRepository;

    @Test
    void storeLoadEntities() {

        Item item = new Item("Foo");
        Bid bid = new Bid(BigDecimal.valueOf(100), item);
        Bid bid2 = new Bid(BigDecimal.valueOf(200), item);

        itemRepository.save(item);
        bidRepository.save(bid);
        bidRepository.save(bid2);

        // В случае если мы делаем выборку только Item, то Hiber выполнит только одни оператор select
        // select item0_.id as id1_1_, item0_.name as name2_1_ from Item item0_
        List<Item> items = itemRepository.findAll();

        // А вот Если мы обратим к сущности Bid, то Hiber автоматически вызвовет еще одни оператор select
        // select bid0_.id as id1_0_, bid0_.amount as amount2_0_, bid0_.ITEM_ID as item_id3_0_ from Bid bid0_ where bid0_.ITEM_ID=?
        List<Bid> bids = bidRepository.findByItem(item);

        assertAll(
                () -> assertEquals(1, items.size()),
                () -> assertEquals(2, bids.size())
        );

    }
}
