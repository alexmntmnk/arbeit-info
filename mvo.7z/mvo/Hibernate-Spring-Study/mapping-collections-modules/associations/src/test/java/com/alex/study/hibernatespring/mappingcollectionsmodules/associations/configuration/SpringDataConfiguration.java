package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Properties;

@EnableJpaRepositories(SpringDataConfiguration.REPO_PATH)
public class SpringDataConfiguration {

    private static final String REPO_PATH_SET_OF_STRING = "com.alex.study.hibernatespring.mappingcollectionsmodules.collections.repositories.setofstrings";
    private static final String MODEL_PATH_SET_OF_STRING = "com.alex.study.hibernatespring.mappingcollectionsmodules.collections.model.setofstrings";

    // private static final String REPO_PATH = "com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.bidirectional";
    // private static final String MODEL_PATH = "com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.bidirectional";

    // private static final String REPO_PATH = "com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.bidirectionaltwo";
    // private static final String MODEL_PATH = "com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.bidirectionaltwo";

    // private static final String REPO_PATH = "com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.cascadepersist";
    // private static final String MODEL_PATH = "com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.cascadepersist";

    // private static final String REPO_PATH = "com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.cascaderemove";
    // private static final String MODEL_PATH = "com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.cascaderemove";

    private static final String REPO_PATH = "com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.orphanremoval";
    private static final String MODEL_PATH = "com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.orphanremoval";
    

    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://10.151.68.8:3306/CH08_MAPPING_ASSOCIATIONS?serverTimezone=UTC");
        dataSource.setUsername("root");
        dataSource.setPassword("rtms");
        return dataSource;
    }

    @Bean
    public JpaTransactionManager transactionManager(EntityManagerFactory emf) {
        return new JpaTransactionManager(emf);
    }

    @Bean
    public JpaVendorAdapter jpaVendorAdapter() {
        HibernateJpaVendorAdapter jpaVendorAdapter = new HibernateJpaVendorAdapter();
        jpaVendorAdapter.setDatabase(Database.MYSQL);
        jpaVendorAdapter.setShowSql(true);
        return jpaVendorAdapter;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean =
                new LocalContainerEntityManagerFactoryBean();
        localContainerEntityManagerFactoryBean.setDataSource(dataSource());
        Properties properties = new Properties();
        properties.put("hibernate.hbm2ddl.auto", "create");
        localContainerEntityManagerFactoryBean.setJpaProperties(properties);
        localContainerEntityManagerFactoryBean.setJpaVendorAdapter(jpaVendorAdapter());
        localContainerEntityManagerFactoryBean.setPackagesToScan(MODEL_PATH);
        return localContainerEntityManagerFactoryBean;
    }
}
