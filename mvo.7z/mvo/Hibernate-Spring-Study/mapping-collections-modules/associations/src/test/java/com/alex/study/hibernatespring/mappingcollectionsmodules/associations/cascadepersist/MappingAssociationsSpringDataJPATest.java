package com.alex.study.hibernatespring.mappingcollectionsmodules.associations.cascadepersist;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.configuration.SpringDataConfiguration;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.cascadepersist.Bid;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.model.cascadepersist.Item;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.cascadepersist.BidRepository;
import com.alex.study.hibernatespring.mappingcollectionsmodules.associations.repositories.cascadepersist.ItemRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SpringDataConfiguration.class})
public class MappingAssociationsSpringDataJPATest {

    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private BidRepository bidRepository;

    @Test
    void storeLoadEntities() {

        Item item = new Item("Cascad-Pre");

        Bid bid = new Bid(BigDecimal.valueOf(10), item);
        Bid bid2 = new Bid(BigDecimal.valueOf(20), item);
        Bid bid3 = new Bid(BigDecimal.valueOf(30), item);
        item.addBid(bid);
        item.addBid(bid2);
        item.addBid(bid3);

        // Мы сохраняем ставки автоматически, но позже. Во время фиксации Spring Data JPA 
        // использует Hibernate проверяет экземпляр управляемого/постоянного элемента 
        // и просматривает коллекцию заявок. Затем он вызывает save() внутренне для каждого 
        // из упомянутых экземпляров Bid, также сохраняя их. Значение, сохраненное в 
        // столбце BID#ITEM_ID, берется из каждой заявки путем проверки свойства Bid#item. 
        // Столбец внешнего ключа сопоставляется с помощью @ManyToOne в этом свойстве.
        itemRepository.save(item);
        long curId = item.getId();

        Item itemTwo = new Item("Cascad-Pre-two");

        Bid bidTwo = new Bid(BigDecimal.valueOf(15), itemTwo);
        Bid bid2Two = new Bid(BigDecimal.valueOf(25), itemTwo);
        Bid bid3Two = new Bid(BigDecimal.valueOf(35), itemTwo);
        itemTwo.addBid(bidTwo);
        itemTwo.addBid(bid2Two);
        itemTwo.addBid(bid3Two);

        itemRepository.save(itemTwo);
        long curIdTwo = itemTwo.getId();        

        List<Item> items = itemRepository.findAll();
        Set<Bid> bids = bidRepository.findByItem(item);

        assertAll(
                () -> assertEquals(2, items.size()),
                () -> assertEquals(3, bids.size())
        );
        
        Item retrievedItem = itemRepository.findById(curId).get();

        // Удалим сначала ставки этого товара, а затем сам товар
        for (Bid someBid : bidRepository.findByItem(retrievedItem)) {
            bidRepository.delete(someBid);
        }
        itemRepository.delete(retrievedItem);

        // А теперь попробуем каскадное удаление второго обьекта
        Item retrievedItemTwo = itemRepository.findById(curIdTwo).get();
        // В итоге получаем ошибку DataIntegrityViolationException, т.к. у нас оно не настроено
        // itemRepository.delete(retrievedItemTwo);

        List<Item> items2 = itemRepository.findAll();
        Set<Bid> bids2 = bidRepository.findByItem(item);

        assertAll(
                () -> assertEquals(1, items2.size()),
                () -> assertEquals(0, bids2.size())
        );
    }
}
