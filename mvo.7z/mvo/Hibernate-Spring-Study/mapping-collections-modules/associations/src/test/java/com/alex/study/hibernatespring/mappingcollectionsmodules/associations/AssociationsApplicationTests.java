package com.alex.study.hibernatespring.mappingcollectionsmodules.associations;

import org.junit.jupiter.api.Test;
class AssociationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
