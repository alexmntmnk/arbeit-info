package com.alex.study.hibernatespring.mappingcollectionsmodules.collections;

import org.junit.jupiter.api.Test;

class CollectionsApplicationTests {

	// @Test
	void contextLoads() {
	}

}
