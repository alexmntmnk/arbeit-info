package com.alex.study.hibernatespring.mappingcollectionsmodules.collections.testlist.embeddablesetofstrings;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alex.study.hibernatespring.mappingcollectionsmodules.collections.configuration.SpringDataConfiguration.SpringDataConfiguration;
import com.alex.study.hibernatespring.mappingcollectionsmodules.collections.model.embeddablesetofstrings.Address;
import com.alex.study.hibernatespring.mappingcollectionsmodules.collections.model.embeddablesetofstrings.User;
import com.alex.study.hibernatespring.mappingcollectionsmodules.collections.repositories.embeddablesetofstrings.UserRepository;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SpringDataConfiguration.class})
public class MappingCollectionsSpringDataJPATest {

    @Autowired
    private UserRepository userRepository;

    @Test
    void storeLoadEntities() {
        User john = new User("john");
        Address address = new Address("Flowers Street", "01246", "Boston");
        address.addContact("John Smith");
        address.addContact("Jane Smith");
        john.setAddress(address);

        userRepository.save(john);

        List<User> users = userRepository.findAll();

        assertAll(
                () -> assertEquals(1, users.size()),
                () -> assertEquals("Flowers Street", users.get(0).getAddress().getStreet()),
                () -> assertEquals("01246", users.get(0).getAddress().getZipcode()),
                () -> assertEquals("Boston", users.get(0).getAddress().getCity()),
                () -> assertEquals(2, users.get(0).getAddress().getContacts().size())
        );

    }
}
