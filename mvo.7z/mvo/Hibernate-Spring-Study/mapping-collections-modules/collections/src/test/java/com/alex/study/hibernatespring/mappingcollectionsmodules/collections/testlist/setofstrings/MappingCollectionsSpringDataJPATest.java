package com.alex.study.hibernatespring.mappingcollectionsmodules.collections.testlist.setofstrings;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.alex.study.hibernatespring.mappingcollectionsmodules.collections.configuration.SpringDataConfiguration.SpringDataConfiguration;
import com.alex.study.hibernatespring.mappingcollectionsmodules.collections.model.setofstrings.Item;
import com.alex.study.hibernatespring.mappingcollectionsmodules.collections.repositories.setofstrings.ItemRepository;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SpringDataConfiguration.class})
public class MappingCollectionsSpringDataJPATest {

    @Autowired
    private ItemRepository itemRepository;

    @Test
    void storeLoadEntities() {

        Item item = new Item("Foo");

        item.addImage("background.jpg");
        item.addImage("foreground.jpg");
        item.addImage("landscape.jpg");
        item.addImage("portrait.jpg");

        itemRepository.save(item);

        Item itemTwo = new Item("Two");

        itemTwo.addImage("background.jpg");
        itemTwo.addImage("foreground.jpg");
        itemTwo.addImage("landscape.jpg");
        itemTwo.addImage("portrait.jpg");

        itemRepository.save(itemTwo);

        Item item2 = itemRepository.findItemWithImages(item.getId());

        List<Item> items2 = itemRepository.findAll();
        Set<String> images = itemRepository.findImagesNative(item.getId());

        for(Item cur: items2) {
            System.out.println("images id " + cur.getId());
            System.out.println("images name " + cur.getName());
        }

        assertAll(
                () -> assertEquals(4, item2.getImages().size()),
                () -> assertEquals(2, items2.size()),
                () -> assertEquals(4, images.size())
        );

        itemRepository.delete(itemTwo);

    }
}
