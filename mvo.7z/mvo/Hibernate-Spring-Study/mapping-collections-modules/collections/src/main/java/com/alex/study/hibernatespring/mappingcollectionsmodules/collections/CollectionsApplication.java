package com.alex.study.hibernatespring.mappingcollectionsmodules.collections;

public class CollectionsApplication {

	public static void main(String[] args) {
	}

}
