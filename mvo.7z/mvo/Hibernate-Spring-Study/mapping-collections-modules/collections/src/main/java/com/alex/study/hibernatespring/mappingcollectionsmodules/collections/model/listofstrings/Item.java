package com.alex.study.hibernatespring.mappingcollectionsmodules.collections.model.listofstrings;

import javax.persistence.*;

import com.alex.study.hibernatespring.mappingcollectionsmodules.collections.Constants;

import java.util.*;

@Entity
public class Item {

    @Id
    @GeneratedValue(generator = Constants.ID_GENERATOR)
    private Long id;

    private String name;

    @ElementCollection
    @CollectionTable(name = "IMAGE") // Default, actually
    @OrderColumn // Enables persistent order, Defaults to IMAGES_ORDER
    @Column(name = "FILENAME") // Defaults to IMAGES
    private List<String> images = new ArrayList<>();

    public Item(String name) {
        this.name = name;
    }

    public Item() {

    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<String> getImages() {
        return Collections.unmodifiableList(images);
    }

    public void addImage(String image) {
        images.add(image);
    }

    public void delImage(String image) {
        images.remove(image);
    }

}
