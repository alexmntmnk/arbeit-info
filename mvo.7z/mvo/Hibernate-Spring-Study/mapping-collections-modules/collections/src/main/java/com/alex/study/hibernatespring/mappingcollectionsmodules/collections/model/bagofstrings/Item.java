package com.alex.study.hibernatespring.mappingcollectionsmodules.collections.model.bagofstrings;

import org.hibernate.annotations.GenericGenerator;

import com.alex.study.hibernatespring.mappingcollectionsmodules.collections.Constants;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

@Entity
public class Item {

    @Id
    @GeneratedValue(generator = Constants.ID_GENERATOR)
    private Long id;

    private String name;

    @ElementCollection
    @CollectionTable(name = "IMAGE")
    @Column(name = "FILENAME")
    // Объявим @GenericGenerator с именем "sequence_gen" и стратегией "sequence" 
    // чтобы позаботиться о суррогатных ключах в таблице Image.
    @GenericGenerator(name = "sequence_gen", strategy = "sequence")
    //Таблице коллекции Image требуется другой первичный ключ, чтобы разрешить дублирование ИМЕНИ файла
    //значения для каждого ITEM_ID.
    @org.hibernate.annotations.CollectionId( // Surrogate PK allows duplicates!
            // Т.к. таблице нужен первичный ключ - зададим его указав столбец суррогатного
            // первичного ключа с именем IMAGE_ID. Вы можете извлекать все
            columns = @Column(name = "IMAGE_ID"),
            // только для Hibernate
            type = @org.hibernate.annotations.Type(type = "long"),
            // Настроим способ генерации первичного ключа
            generator = "sequence_gen")
    private Collection<String> images = new ArrayList<>(); // No BagImpl in JDK!

    public Item(String name) {
        this.name = name;
    }

    public Item() {

    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Collection<String> getImages() {
        return Collections.unmodifiableCollection(images);
    }

    public void addImage(String image) {
        images.add(image);
    }
}
