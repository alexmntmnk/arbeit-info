package com.alex.study.hibernatespring.mappingcollectionsmodules.collections.repositories.embeddablesetofstrings;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alex.study.hibernatespring.mappingcollectionsmodules.collections.model.embeddablesetofstrings.User;

public interface UserRepository extends JpaRepository<User, Long> {

}
