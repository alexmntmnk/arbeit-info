### Relevant Articles:

- [Using Custom User Providers with Keycloak](https://www.baeldung.com/java-keycloak-custom-user-providers)
В этом руководстве мы покажем, как добавить собственного поставщика в Keycloak , популярное решение для управления идентификацией с открытым исходным кодом, чтобы мы могли использовать его с существующими и/или нестандартными хранилищами пользователей.