INSERT INTO Foo(id, name) VALUES (1, 'Foo 1');
INSERT INTO Foo(id, name) VALUES (2, 'Foo 2');
INSERT INTO Foo(id, name) VALUES (3, 'Foo 3');

