package ru.javabegin.micro.planner.plannergateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlannerGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
